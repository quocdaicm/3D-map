import { css, keyframes } from "@emotion/react";
import { Space } from "../three/Space";
import { FullscreenModal } from "../components/FullscreenModal";
import { Title } from "@/components/text/Title";
import { Description } from "@/components/text/Description";
import { Column } from "@/components/flex/Column";
import { MapComponent } from "@/components/map/SelectMap";
import { useEffect, useState } from "react";
import {
  Button,
  NextButton,
  PrevButton,
} from "@/components/button/BottomButton";
import { BuildingHeights, Building } from "@/components/map/Processing";
import { ChevronLeft, ChevronRight, Download, Loader2 } from "lucide-react";
import { useAreaStore } from "@/state/areaStore";
import { useActionStore, ExportType } from "@/state/exportStore";
import { Modal } from "@/components/modal/Modal";
import { TopNav } from "@/components/nav/TopNav";
import { Row } from "@/components/flex/Row";
import { History } from "@/components/map/History";
import {
  HistoryItem,
  loadHistory,
  loadBuildings,
  saveHistory,
  removeHistory,
} from "@/utils/history";
import { tap, success, warn } from "@/utils/haptics";

const IconSize = css({
  width: "14px",
  height: "14px",
});

const spinAnimation = keyframes`
from { transform: rotate(0deg); }
to { transform: rotate(360deg); }
`;

function App() {
  const [isNextButtonDisabled, setIsNextButtonDisabled] = useState(true);
  const [areaData, setAreaData] = useState([]);
  const [steps, setSteps] = useState(["front", "processing"]);
  const [step, setStep] = useState(0);
  const [isWarnModal, setIsWarnModal] = useState(false);
  const [isExportModal, setIsExportModal] = useState(false);
  const [buildings, setBuildings] = useState<Building[]>([]);
  const [isFetchingBuildings, setIsFetchingBuildings] = useState(false);
  const [hasFetchedBuildings, setHasFetchedBuildings] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);

  const setCenter = useAreaStore((state) => state.setCenter);
  const appendAreas = useAreaStore((state) => state.appendAreas);
  const setAction = useActionStore((state) => state.setAction);

  const checkIsBig = () => {
    const a = Math.abs(areaData[0].lat - areaData[1].lat);
    const b = Math.abs(areaData[0].lng - areaData[1].lng);

    if (a + b > 0.1) {
      return true;
    } else {
      return false;
    }
  };

  const setExportType = useActionStore((state) => state.setExportType);

  const exportFile = (type: ExportType = "glb") => {
    setExportType(type);
    setAction(true);
  };

  const handleDone = (data) => {
    setAreaData(data);
    setCenter(data);
    console.log(data, "AAEE");
    setIsNextButtonDisabled(false);
    setBuildings([]);
    setHasFetchedBuildings(false);
    setFetchError(null);
  };

  const handleRemove = () => {
    setAreaData([]);
    setIsNextButtonDisabled(true);
    setBuildings([]);
    setHasFetchedBuildings(false);
  };

  const requestBuildings = async () => {
    setIsFetchingBuildings(true);

    const south = areaData[1].lat;
    const west = areaData[1].lng;
    const north = areaData[0].lat;
    const east = areaData[0].lng;
    const query = `[out:json][timeout:25];(way["building"]( ${south},${west},${north},${east} );relation["building"]( ${south},${west},${north},${east} ););out body geom;`;
    setFetchError(null);
    const servers = [
      "https://overpass-api.de/api/interpreter",
      "https://overpass.kumi.systems/api/interpreter",
      "https://overpass.private.coffee/api/interpreter",
    ];
    let lastError = "";
    for (const server of servers) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 30000);
      try {
        const response = await fetch(server, {
          method: "POST",
          body: "data=" + encodeURIComponent(query),
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          signal: controller.signal,
        });
        if (!response.ok) throw new Error("Máy chủ trả về lỗi " + response.status);
        const data = await response.json();
        if (data.remark && /error|timed out|out of memory/i.test(data.remark)) {
          throw new Error("Máy chủ quá tải, vùng chọn có thể quá lớn");
        }
        const blds: Building[] = data.elements.map((element) => ({
          id: element.id,
          tags: element.tags || {},
          geometry: element.geometry
            ? element.geometry.map((pt) => ({ lat: pt.lat, lng: pt.lon }))
            : undefined,
        }));
        if (blds.length === 0) {
          setFetchError(
            "Không có tòa nhà nào trong vùng đã chọn. Hãy quay lại và chọn vùng khác."
          );
          setIsFetchingBuildings(false);
          clearTimeout(timer);
          return;
        }
        setBuildings(blds);
        appendAreas(blds);
        setHasFetchedBuildings(true);
        clearTimeout(timer);
        setIsFetchingBuildings(false);
        success();
        saveHistory(areaData as any, blds).then(setHistory);
        return;
      } catch (error: any) {
        lastError =
          error?.name === "AbortError"
            ? "Hết thời gian chờ"
            : error?.message || "Lỗi không xác định";
        console.error("Overpass error", server, error);
      } finally {
        clearTimeout(timer);
      }
    }
    warn();
    setFetchError(
      `Không tải được dữ liệu tòa nhà (${lastError}). Kiểm tra mạng hoặc thu nhỏ vùng chọn rồi thử lại.`
    );
    setIsFetchingBuildings(false);
  };

  const handleClickNextStep = async () => {
    tap();
    if (step == 0 && checkIsBig()) {
      setIsWarnModal(true);
      return false;
    }
    if (step == 1 && !hasFetchedBuildings) {
      await requestBuildings();
      return;
    }
    setStep(step + 1);
  };

  const handleClickPrevStep = () => {
    setStep(step - 1);
  };

  const handleClickExport = () => {
    setIsExportModal(true);
  };

  useEffect(() => {
    loadHistory().then(setHistory);
  }, []);

  const handleOpenHistory = async (item: HistoryItem) => {
    tap();
    const blds = await loadBuildings(item.id);
    if (!blds.length) {
      alert("Không đọc được dữ liệu đã lưu của vùng này.");
      return;
    }
    setAreaData(item.bounds as any);
    setCenter(item.bounds as any);
    setBuildings(blds);
    appendAreas(blds);
    setHasFetchedBuildings(true);
    setFetchError(null);
    setIsNextButtonDisabled(false);
    setStep(2);
  };

  const handleRemoveHistory = async (item: HistoryItem) => {
    setHistory(await removeHistory(item.id));
  };

  return (
    <div css={css({ height: "100%", width: "100%" })}>
      <TopNav step={step} />

      <FullscreenModal isOpen={steps[step] == "front"}>
        <Column gap="1rem">
          <Column gap="0.5rem">
            <Title>Tạo bản đồ 3D</Title>
            <Description>
              Chọn một vùng trên bản đồ, lấy dữ liệu tòa nhà từ OpenStreetMap
              và xuất mô hình 3D dạng GLB.
            </Description>
          </Column>
          <MapComponent
            onRemove={handleRemove}
            onDone={handleDone}
          ></MapComponent>
          <History
            items={history}
            onOpen={handleOpenHistory}
            onRemove={handleRemoveHistory}
          />
        </Column>
      </FullscreenModal>

      <FullscreenModal isOpen={steps[step] == "processing"}>
        <Column gap="1rem">
          <Column gap="0.5rem">
            <Title>Dữ liệu tòa nhà</Title>
            <Description>
              Nhấn “Tải dữ liệu” để lấy thông tin tòa nhà. Khi tải xong, nhấn
              “Xem 3D” để mở cảnh 3D.
            </Description>

            <BuildingHeights
              buildings={buildings}
              loading={isFetchingBuildings}
              error={fetchError}
            />
          </Column>
        </Column>
      </FullscreenModal>

      <PrevButton isShow={step != 0} onClick={handleClickPrevStep}>
        <ChevronLeft css={IconSize} /> Quay lại
      </PrevButton>

      <NextButton
        isShow={step != 2}
        disabled={isNextButtonDisabled || isFetchingBuildings}
        onClick={handleClickNextStep}
      >
        {isFetchingBuildings ? (
          <>
            <Loader2
              css={[
                IconSize,
                css({ animation: `${spinAnimation} 1s linear infinite` }),
              ]}
            />
            Đang tải...
          </>
        ) : (
          <>
            {step == 1 && !hasFetchedBuildings ? (fetchError ? "Thử lại" : "Tải dữ liệu") : step == 1 ? "Xem 3D" : "Tiếp tục"}{" "}
            <ChevronRight css={IconSize} />
          </>
        )}
      </NextButton>

      <NextButton isShow={step == 2} onClick={handleClickExport}>
        Xuất GLB <Download css={IconSize} />
      </NextButton>

      <Modal isOpen={isWarnModal} onClose={() => setIsWarnModal(false)}>
        <Column gap="0.5rem">
          <Title>Vùng chọn quá lớn</Title>
          <Description>Vùng lớn có thể tải lâu và làm app chậm. Bạn vẫn muốn tiếp tục?</Description>
          <Button
            isShow={step != 2}
            disabled={isNextButtonDisabled}
            onClick={() => {
              setStep(step + 1);
              setIsWarnModal(false);
            }}
          >
            Tiếp tục <ChevronRight css={IconSize} />
          </Button>
        </Column>
      </Modal>

      <Modal isOpen={isExportModal} onClose={() => setIsExportModal(false)}>
        <Column gap="0.5rem">
          <Title>Xuất file</Title>

          <Row gap="0.5rem" wrap>
            <Button isShow={true} onClick={() => exportFile("glb")}>
              Tải GLB <Download css={IconSize} />
            </Button>

            <Button isShow={true} onClick={() => exportFile("usdz")}>
              Xem AR (USDZ) <Download css={IconSize} />
            </Button>

            <Button isShow={true} onClick={() => exportFile("obj")}>
              OBJ <Download css={IconSize} />
            </Button>

            <Button isShow={true} onClick={() => exportFile("stl")}>
              STL (in 3D) <Download css={IconSize} />
            </Button>
          </Row>
        </Column>
      </Modal>

      <Space active={step === 2} />
    </div>
  );
}

export default App;
