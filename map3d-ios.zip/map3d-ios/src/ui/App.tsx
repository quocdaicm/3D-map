import { css, keyframes } from "@emotion/react";
import { Space } from "../three/Space";
import { FullscreenModal } from "../components/FullscreenModal";
import { Title } from "@/components/text/Title";
import { Description } from "@/components/text/Description";
import { Column } from "@/components/flex/Column";
import { MapComponent } from "@/components/map/SelectMap";
import { useEffect, useState } from "react";
import {
  Button,
  NextButton,
  PrevButton,
} from "@/components/button/BottomButton";
import { BuildingHeights, Building } from "@/components/map/Processing";
import { ChevronLeft, ChevronRight, Download, Loader2 } from "lucide-react";
import { useAreaStore } from "@/state/areaStore";
import { useActionStore, ExportType } from "@/state/exportStore";
import { Modal } from "@/components/modal/Modal";
import { TopNav } from "@/components/nav/TopNav";
import { Row } from "@/components/flex/Row";
import { History } from "@/components/map/History";
import {
  HistoryItem,
  loadHistory,
  loadBuildings,
  saveHistory,
  removeHistory,
} from "@/utils/history";
import { tap, success, warn } from "@/utils/haptics";
import { overpass } from "@/utils/overpass";

const IconSize = css({
  width: "14px",
  height: "14px",
});

const spinAnimation = keyframes`
from { transform: rotate(0deg); }
to { transform: rotate(360deg); }
`;

function App() {
  const [isNextButtonDisabled, setIsNextButtonDisabled] = useState(true);
  const [areaData, setAreaData] = useState([]);
  const [steps, setSteps] = useState(["front", "processing"]);
  const [step, setStep] = useState(0);
  const [isWarnModal, setIsWarnModal] = useState(false);
  const [isExportModal, setIsExportModal] = useState(false);
  const [buildings, setBuildings] = useState<Building[]>([]);
  const [isFetchingBuildings, setIsFetchingBuildings] = useState(false);
  const [hasFetchedBuildings, setHasFetchedBuildings] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);

  const setCenter = useAreaStore((state) => state.setCenter);
  const appendAreas = useAreaStore((state) => state.appendAreas);
  const setAction = useActionStore((state) => state.setAction);

  const checkIsBig = () => {
    const a = Math.abs(areaData[0].lat - areaData[1].lat);
    const b = Math.abs(areaData[0].lng - areaData[1].lng);

    if (a + b > 0.1) {
      return true;
    } else {
      return false;
    }
  };

  const setExportType = useActionStore((state) => state.setExportType);

  const exportFile = (type: ExportType = "glb") => {
    setExportType(type);
    setAction(true);
  };

  const handleDone = (data) => {
    setAreaData(data);
    setCenter(data);
    console.log(data, "AAEE");
    setIsNextButtonDisabled(false);
    setBuildings([]);
    setHasFetchedBuildings(false);
    setFetchError(null);
  };

  const handleRemove = () => {
    setAreaData([]);
    setIsNextButtonDisabled(true);
    setBuildings([]);
    setHasFetchedBuildings(false);
  };

  const requestBuildings = async () => {
    setIsFetchingBuildings(true);

    const south = areaData[1].lat;
    const west = areaData[1].lng;
    const north = areaData[0].lat;
    const east = areaData[0].lng;
    const query = `[out:json][timeout:40];(way["building"](${south},${west},${north},${east});relation["building"](${south},${west},${north},${east}););out geom;`;
    setFetchError(null);
    try {
      const data = await overpass(query);
      const blds: Building[] = [];
      for (const element of data.elements || []) {
        if (element.type === "relation") {
          // Tòa nhà dạng multipolygon: lấy các vành ngoài
          (element.members || []).forEach((m, i) => {
            if (m.role === "outer" && m.geometry && m.geometry.length >= 3) {
              blds.push({
                id: `${element.id}_${i}`,
                tags: element.tags || {},
                geometry: m.geometry.map((pt) => ({ lat: pt.lat, lng: pt.lon })),
              } as any);
            }
          });
        } else {
          blds.push({
            id: element.id,
            tags: element.tags || {},
            geometry: element.geometry
              ? element.geometry.map((pt) => ({ lat: pt.lat, lng: pt.lon }))
              : undefined,
          } as any);
        }
      }
      if (blds.filter((b) => b.geometry && b.geometry.length >= 3).length === 0) {
        // OSM chưa có tòa nhà ở vùng này: vẫn cho dựng địa hình và đường
        alert(
          "OpenStreetMap chưa có dữ liệu tòa nhà ở vùng này (đã thử cả tòa nhà dạng vùng phức hợp). Vẫn dựng địa hình và đường; bạn có thể quay lại chọn vùng khác."
        );
        setBuildings([]);
        appendAreas([]);
        setHasFetchedBuildings(true);
        setIsFetchingBuildings(false);
        return;
      }
      setBuildings(blds);
      appendAreas(blds);
      setHasFetchedBuildings(true);
      setIsFetchingBuildings(false);
      success();
      saveHistory(areaData as any, blds).then(setHistory);
    } catch (error: any) {
      warn();
      setFetchError(
        "Không tải được dữ liệu tòa nhà. Chi tiết:\n" +
          (error?.message || "lỗi không rõ") +
          "\nHãy thử lại sau ít phút, hoặc chọn vùng nhỏ hơn."
      );
      setIsFetchingBuildings(false);
    }
  };

  const handleClickNextStep = async () => {
    tap();
    if (step == 0 && checkIsBig()) {
      setIsWarnModal(true);
      return false;
    }
    if (step == 1 && !hasFetchedBuildings) {
      await requestBuildings();
      return;
    }
    setStep(step + 1);
  };

  const handleClickPrevStep = () => {
    setStep(step - 1);
  };

  const handleClickExport = () => {
    setIsExportModal(true);
  };

  useEffect(() => {
    loadHistory().then(setHistory);
  }, []);

  const handleOpenHistory = async (item: HistoryItem) => {
    tap();
    const blds = await loadBuildings(item.id);
    if (!blds.length) {
      alert("Không đọc được dữ liệu đã lưu của vùng này.");
      return;
    }
    setAreaData(item.bounds as any);
    setCenter(item.bounds as any);
    setBuildings(blds);
    appendAreas(blds);
    setHasFetchedBuildings(true);
    setFetchError(null);
    setIsNextButtonDisabled(false);
    setStep(2);
  };

  const handleRemoveHistory = async (item: HistoryItem) => {
    setHistory(await removeHistory(item.id));
  };

  return (
    <div css={css({ height: "100%", width: "100%" })}>
      <TopNav step={step} />

      <FullscreenModal isOpen={steps[step] == "front"}>
        <Column gap="1rem">
          <Column gap="0.5rem">
            <Title>Tạo bản đồ 3D</Title>
            <Description>
              Chọn một vùng trên bản đồ, lấy dữ liệu tòa nhà từ OpenStreetMap
              và xuất mô hình 3D dạng GLB.
            </Description>
          </Column>
          <MapComponent
            onRemove={handleRemove}
            onDone={handleDone}
          ></MapComponent>
          <History
            items={history}
            onOpen={handleOpenHistory}
            onRemove={handleRemoveHistory}
          />
        </Column>
      </FullscreenModal>

      <FullscreenModal isOpen={steps[step] == "processing"}>
        <Column gap="1rem">
          <Column gap="0.5rem">
            <Title>Dữ liệu tòa nhà</Title>
            <Description>
              Nhấn “Tải dữ liệu” để lấy thông tin tòa nhà. Khi tải xong, nhấn
              “Xem 3D” để mở cảnh 3D.
            </Description>

            <BuildingHeights
              buildings={buildings}
              loading={isFetchingBuildings}
              error={fetchError}
            />
          </Column>
        </Column>
      </FullscreenModal>

      <PrevButton isShow={step != 0} onClick={handleClickPrevStep}>
        <ChevronLeft css={IconSize} /> Quay lại
      </PrevButton>

      <NextButton
        isShow={step != 2}
        disabled={isNextButtonDisabled || isFetchingBuildings}
        onClick={handleClickNextStep}
      >
        {isFetchingBuildings ? (
          <>
            <Loader2
              css={[
                IconSize,
                css({ animation: `${spinAnimation} 1s linear infinite` }),
              ]}
            />
            Đang tải...
          </>
        ) : (
          <>
            {step == 1 && !hasFetchedBuildings ? (fetchError ? "Thử lại" : "Tải dữ liệu") : step == 1 ? "Xem 3D" : "Tiếp tục"}{" "}
            <ChevronRight css={IconSize} />
          </>
        )}
      </NextButton>

      <NextButton isShow={step == 2} onClick={handleClickExport}>
        Xuất GLB <Download css={IconSize} />
      </NextButton>

      <Modal isOpen={isWarnModal} onClose={() => setIsWarnModal(false)}>
        <Column gap="0.5rem">
          <Title>Vùng chọn quá lớn</Title>
          <Description>Vùng lớn có thể tải lâu và làm app chậm. Bạn vẫn muốn tiếp tục?</Description>
          <Button
            isShow={step != 2}
            disabled={isNextButtonDisabled}
            onClick={() => {
              setStep(step + 1);
              setIsWarnModal(false);
            }}
          >
            Tiếp tục <ChevronRight css={IconSize} />
          </Button>
        </Column>
      </Modal>

      <Modal isOpen={isExportModal} onClose={() => setIsExportModal(false)}>
        <Column gap="0.5rem">
          <Title>Xuất file</Title>

          <Row gap="0.5rem" wrap>
            <Button isShow={true} onClick={() => exportFile("glb")}>
              Tải GLB <Download css={IconSize} />
            </Button>

            <Button isShow={true} onClick={() => exportFile("usdz")}>
              Xem AR (USDZ) <Download css={IconSize} />
            </Button>

            <Button isShow={true} onClick={() => exportFile("obj")}>
              OBJ <Download css={IconSize} />
            </Button>

            <Button isShow={true} onClick={() => exportFile("stl")}>
              STL (in 3D) <Download css={IconSize} />
            </Button>
          </Row>
        </Column>
      </Modal>

      <Space active={step === 2} />
    </div>
  );
}

export default App;
