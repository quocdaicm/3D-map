import { create } from "zustand";

export type ExportType = "glb" | "usdz" | "obj" | "stl";

type ActionStore = {
  action: boolean;
  exportType: ExportType;

  setAction: (action: boolean) => void;
  setExportType: (exportType: ExportType) => void;
};

export const useActionStore = create<ActionStore>((set) => ({
  action: false,
  exportType: "glb",
  setAction: (action) => set(() => ({ action })),
  setExportType: (exportType) => set(() => ({ exportType })),
}));
