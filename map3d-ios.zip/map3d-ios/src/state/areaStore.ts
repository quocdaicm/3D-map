import { create } from "zustand";

type AreaStore = {
  areas: any;
  center: {
    lat: number;
    lng: number;
  }[];
  /** Chiều cao do người dùng chỉnh tay, theo id tòa nhà (mét) */
  heightOverrides: Record<string, number>;

  appendAreas: (areas: any[]) => void;
  setCenter: (center: any[]) => void;
  setHeight: (id: string | number, height: number | null) => void;
};

export const useAreaStore = create<AreaStore>((set) => ({
  areas: [],
  center: [
    {
      lat: 40.8,
      lng: -73.95,
    },
    {
      lat: 40.83,
      lng: -73.88,
    },
  ],
  heightOverrides: {},
  appendAreas: (areas) =>
    set(() => ({ areas: [...areas], heightOverrides: {} })),
  setCenter: (center) => set(() => ({ center: [...center] })),
  setHeight: (id, height) =>
    set((state) => {
      const next = { ...state.heightOverrides };
      if (height === null) delete next[String(id)];
      else next[String(id)] = height;
      return { heightOverrides: next };
    }),
}));
