export const BORDER_COLOR = "#0b1f2e14";
export const SUBTITLE_COLOR = "#0b1f2e";
export const DESC_COLOR = "#5a6b78";
export const ACTION_ICON_COLOR = "#0b1f2e";

export const PRIMARY = "#0e9aa7";
export const PRIMARY_DARK = "#0b7c87";
export const ACCENT = "#f7ad2b";
export const INK = "#0b1f2e";
export const GLASS = "rgba(255,255,255,0.82)";
export const SHADOW = "0 8px 28px rgba(11,31,46,0.16)";
export const SAFE_TOP = "env(safe-area-inset-top)";
export const SAFE_BOTTOM = "env(safe-area-inset-bottom)";
