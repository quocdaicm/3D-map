import { installDevLog } from "./utils/devLog";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./ui/App.tsx";

// Bộ ghi lỗi/API phải cài trước khi app chạy để bắt được lỗi sớm.
installDevLog();

createRoot(document.getElementById("root")!).render(<App />);
