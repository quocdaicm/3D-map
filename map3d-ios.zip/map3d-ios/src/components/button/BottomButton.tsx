import { css } from "@emotion/react";
import { ButtonHTMLAttributes, DetailedHTMLProps } from "react";
import {
  PRIMARY,
  PRIMARY_DARK,
  INK,
  GLASS,
  SHADOW,
  SAFE_BOTTOM,
} from "@/theme/color";

interface ButtonProps
  extends DetailedHTMLProps<
    ButtonHTMLAttributes<HTMLButtonElement>,
    HTMLButtonElement
  > {
  isShow?: boolean;
}

const base = {
  border: "none",
  padding: "0.85rem 1.35rem",
  borderRadius: "14px",
  fontWeight: 600,
  fontSize: "15px",
  cursor: "pointer",
  transition: "transform .15s, background-color .2s, opacity .2s",
  alignItems: "center",
  justifyContent: "center",
  gap: "0.5rem",
  boxShadow: SHADOW,
  ":active": { transform: "scale(0.97)" },
  ":disabled": { opacity: 0.45, cursor: "not-allowed", boxShadow: "none" },
} as const;

const primary = {
  ...base,
  color: "#ffffff",
  backgroundColor: PRIMARY,
  ":hover": { backgroundColor: PRIMARY_DARK },
  ":active": { transform: "scale(0.97)", backgroundColor: PRIMARY_DARK },
} as const;

const secondary = {
  ...base,
  color: INK,
  backgroundColor: GLASS,
  backdropFilter: "blur(14px)",
  WebkitBackdropFilter: "blur(14px)",
} as const;

export function NextButton(props: ButtonProps) {
  const { isShow, ...rest } = props;
  return (
    <button
      css={css({
        ...primary,
        position: "fixed",
        zIndex: 9999,
        right: "1.25rem",
        bottom: `calc(1.25rem + ${SAFE_BOTTOM})`,
        display: isShow ? "flex" : "none",
      })}
      {...rest}
    >
      {props.children}
    </button>
  );
}

export function PrevButton(props: ButtonProps) {
  const { isShow, ...rest } = props;
  return (
    <button
      css={css({
        ...secondary,
        position: "fixed",
        zIndex: 9999,
        left: "1.25rem",
        bottom: `calc(1.25rem + ${SAFE_BOTTOM})`,
        display: isShow ? "flex" : "none",
      })}
      {...rest}
    >
      {props.children}
    </button>
  );
}

export function Button(props: ButtonProps) {
  const { isShow, ...rest } = props;
  return (
    <button
      css={css({
        ...primary,
        boxShadow: "none",
        display: isShow ? "flex" : "none",
      })}
      {...rest}
    >
      {props.children}
    </button>
  );
}
