import { useCarStore } from "@/state/carStore";
import { css } from "@emotion/react";
import { DetailedHTMLProps, ButtonHTMLAttributes, useState } from "react";
import { Modal } from "../modal/Modal";
import { Column } from "../flex/Column";
import { Title } from "../text/Title";
import { Description } from "../text/Description";
import { BORDER_COLOR, INK, PRIMARY, SAFE_TOP } from "@/theme/color";

const TOP_PANEL_HEIGHT = "3.25rem";
const STEP_TOTAL = 3;

interface ButtonProps
  extends DetailedHTMLProps<
    ButtonHTMLAttributes<HTMLButtonElement>,
    HTMLButtonElement
  > {
  isShow?: boolean;
}

export function TopNav({ step }: { step: number }) {
  const setThirdMode = useCarStore((state) => state.setThirdMode);
  const thirdMode = useCarStore((state) => state.thirdMode);
  const isMobile = /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent);

  const [openModal, setOpenModal] = useState(false);

  return (
    <>
      <div
        css={css({
          display: "flex",
          position: "fixed",
          top: 0,
          left: 0,
          width: "100%",
          boxSizing: "border-box",
          paddingTop: SAFE_TOP,
          height: `calc(${TOP_PANEL_HEIGHT} + ${SAFE_TOP})`,
          backgroundColor: "rgba(255,255,255,0.78)",
          backdropFilter: "blur(18px) saturate(160%)",
          WebkitBackdropFilter: "blur(18px) saturate(160%)",
          borderBottom: `1px solid ${BORDER_COLOR}`,
          zIndex: 10000,
          justifyContent: "space-between",
          alignItems: "center",
          paddingLeft: "1rem",
          paddingRight: "1rem",
        })}
      >
        <div
          css={css({
            display: "flex",
            alignItems: "center",
            gap: "0.6rem",
          })}
        >
          <img
            src="/logo.svg"
            alt="Map3D"
            width={30}
            height={30}
            css={css({ borderRadius: "8px", display: "block" })}
          />
          <span
            css={css({
              fontSize: "17px",
              fontWeight: 700,
              letterSpacing: "-0.02em",
              color: INK,
            })}
          >
            Map<span css={css({ color: PRIMARY })}>3D</span>
          </span>
        </div>

        <div
          css={css({
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            gap: "0.5rem",
          })}
        >
          <span
            css={css({
              fontSize: "12px",
              fontWeight: 600,
              color: PRIMARY,
              backgroundColor: "#0e9aa71a",
              padding: "0.3rem 0.65rem",
              borderRadius: "999px",
            })}
          >
            Bước {step + 1}/{STEP_TOTAL}
          </span>

          <NavButton isShow={step >= 1} onClick={() => setOpenModal(true)}>
            Tùy chọn
          </NavButton>

          {!isMobile && (
            <>
              {thirdMode ? (
                <NavButton
                  isShow={step == 2}
                  onClick={() => setThirdMode(false)}
                >
                  Tắt xe
                </NavButton>
              ) : (
                <NavButton
                  isShow={step == 2}
                  onClick={() => setThirdMode(true)}
                >
                  Chế độ xe
                </NavButton>
              )}
            </>
          )}
        </div>
      </div>

      <Modal isOpen={openModal} onClose={() => setOpenModal(false)}>
        <Column gap="0.5rem">
          <Title>Tùy chọn</Title>
          <Description>Chưa có tùy chọn nào khả dụng.</Description>
        </Column>
      </Modal>
    </>
  );
}

export function NavButton(props: ButtonProps) {
  const { isShow, ...rest } = props;
  return (
    <button
      css={css({
        color: INK,
        backgroundColor: "#0b1f2e0d",
        border: "none",
        padding: "0.4rem 0.8rem",
        borderRadius: "999px",
        fontWeight: 600,
        fontSize: "12px",
        display: isShow ? "" : "none",
        cursor: "pointer",
        ":active": { backgroundColor: "#0b1f2e1a" },
      })}
      {...rest}
    >
      {props.children}
    </button>
  );
}
