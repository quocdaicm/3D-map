import { css } from "@emotion/react";
import { useEffect, useState } from "react";
import { Column } from "../flex/Column";
import { Title } from "../text/Title";
import { Description } from "../text/Description";
import { BORDER_COLOR, DESC_COLOR, INK, PRIMARY } from "@/theme/color";
import { saveText } from "@/utils/saveFile";
import { useAreaStore } from "@/state/areaStore";
import { useCarStore } from "@/state/carStore";
import { useActionStore } from "@/state/exportStore";
import {
  clearErrors,
  clearNet,
  counts,
  exportBundle,
  exportCss,
  exportDomStructure,
  exportEnvironment,
  exportErrors,
  exportHtml,
  exportNetJson,
  exportNetSummary,
  exportNetText,
  fetchUrlText,
  isNetLogOn,
  setNetLogOn,
  subscribe,
} from "@/utils/devLog";

const btn = css({
  width: "100%",
  textAlign: "left",
  border: `1px solid ${BORDER_COLOR}`,
  background: "#f4f9fb",
  color: INK,
  padding: "0.65rem 0.8rem",
  borderRadius: "12px",
  fontSize: "0.9rem",
  fontWeight: 600,
  cursor: "pointer",
  ":active": { background: "#e3eef3" },
});

const dangerBtn = css(btn, { color: "#c0392b" });

const sectionTitle = css({
  margin: "0.9rem 0 0",
  fontSize: "0.8rem",
  fontWeight: 700,
  letterSpacing: "0.04em",
  textTransform: "uppercase",
  color: PRIMARY,
});

const footnote = css({ margin: 0, fontSize: "0.78rem", lineHeight: 1.45, color: DESC_COLOR });

function Toggle({
  label,
  value,
  onChange,
}: {
  label: string;
  value: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label
      css={css({
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "0.75rem",
        fontSize: "0.9rem",
        color: INK,
        padding: "0.25rem 0",
      })}
    >
      <span>{label}</span>
      <input
        type="checkbox"
        checked={value}
        onChange={(e) => onChange(e.target.checked)}
        css={css({ width: 22, height: 22, accentColor: PRIMARY })}
      />
    </label>
  );
}

const readBool = (k: string, d: boolean) => {
  try {
    const v = localStorage.getItem(k);
    return v === null ? d : v === "1";
  } catch {
    return d;
  }
};
const writeBool = (k: string, v: boolean) => {
  try {
    localStorage.setItem(k, v ? "1" : "0");
  } catch {
    /* bỏ qua */
  }
};

export function DevToolsPanel() {
  const [, force] = useState(0);
  const [netOn, setNetOn] = useState(isNetLogOn());
  const [stripValues, setStripValues] = useState(readBool("map3dStripValues", true));
  const [stripScripts, setStripScripts] = useState(readBool("map3dStripScripts", false));
  const [path, setPath] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => subscribe(() => force((n) => n + 1)), []);

  const c = counts();

  const run = async (fn: () => Promise<string | void> | string | void) => {
    if (busy) return;
    setBusy(true);
    setMsg(null);
    try {
      const r = await fn();
      if (typeof r === "string") setMsg(r);
    } catch (e: any) {
      setMsg(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  const stores = () => ({
    area: useAreaStore.getState(),
    car: useCarStore.getState(),
    export: useActionStore.getState(),
  });

  const save = (text: string, prefix: string, ext: string) =>
    run(async () => {
      await saveText(text, prefix, ext);
    });

  const copy = (text: string) =>
    run(async () => {
      try {
        await navigator.clipboard.writeText(text);
        return `Đã sao chép ${text.length.toLocaleString()} ký tự.`;
      } catch {
        return "Không sao chép được — hãy dùng nút Lưu file.";
      }
    });

  const bundle = () => exportBundle({ stores: stores(), stripValues, includeHtml: false });

  return (
    <div data-devtools="1">
      <Column gap="0.5rem">
        <Title>Tùy chọn</Title>
        <Description>
          Công cụ phát triển: lấy API, giao diện và lỗi để gửi cho người sửa app.
        </Description>

        <p css={sectionTitle}>Chẩn đoán nhanh</p>
        <button css={btn} disabled={busy} onClick={() => save(bundle(), "map3d-diag", "txt")}>
          Lưu gói chẩn đoán (1 file)…
        </button>
        <button css={btn} disabled={busy} onClick={() => copy(bundle())}>
          Sao chép gói chẩn đoán
        </button>
        <p css={footnote}>
          Gồm: thiết bị, lỗi, trạng thái app, tóm tắt API, cấu trúc giao diện và CSS. Gặp lỗi thì
          mở màn hình đang lỗi, vào đây lưu file rồi gửi lại.
        </p>

        <p css={sectionTitle}>Nhật ký lỗi ({c.err})</p>
        <button css={btn} disabled={busy} onClick={() => save(exportErrors(), "map3d-errors", "txt")}>
          Lưu nhật ký lỗi…
        </button>
        <button css={btn} disabled={busy} onClick={() => copy(exportErrors())}>
          Sao chép nhật ký lỗi
        </button>
        <button
          css={dangerBtn}
          disabled={busy}
          onClick={() => {
            clearErrors();
            setMsg("Đã xóa nhật ký lỗi.");
          }}
        >
          Xóa nhật ký lỗi
        </button>
        <p css={footnote}>
          Luôn ghi: lỗi JavaScript, lời hứa bị từ chối, console.error/warn, ảnh/script không tải
          được. Lưu cả khi app bị tải lại.
        </p>

        <p css={sectionTitle}>Nhật ký API ({c.net})</p>
        <Toggle
          label="Ghi lại các request API"
          value={netOn}
          onChange={(v) => {
            setNetOn(v);
            setNetLogOn(v);
          }}
        />
        <button css={btn} disabled={busy} onClick={() => save(exportNetJson(), "map3d-api-full", "json")}>
          Lưu nhật ký API (JSON đầy đủ)…
        </button>
        <button css={btn} disabled={busy} onClick={() => save(exportNetSummary(), "map3d-api-summary", "txt")}>
          Lưu tóm tắt các endpoint…
        </button>
        <button css={btn} disabled={busy} onClick={() => save(exportNetText(), "map3d-api", "txt")}>
          Lưu nhật ký API (văn bản)…
        </button>
        <button
          css={dangerBtn}
          disabled={busy}
          onClick={() => {
            clearNet();
            setMsg("Đã xóa nhật ký API.");
          }}
        >
          Xóa nhật ký API
        </button>
        <p css={footnote}>
          Bật công tắc rồi thao tác trong app (chọn vùng, tải tòa nhà, địa hình, ảnh vệ tinh, xuất
          file…), sau đó quay lại lưu. Ghi địa chỉ, tham số, mã trạng thái, thời gian và phản hồi
          (cắt bớt); khóa/token trong địa chỉ được che. Ảnh tile bản đồ không đi qua fetch nên chỉ
          hiện ở phần tóm tắt trong gói chẩn đoán. Nhớ tắt và xóa khi xong.
        </p>

        <p css={sectionTitle}>Giao diện</p>
        <button css={btn} disabled={busy} onClick={() => save(exportDomStructure(), "map3d-structure", "txt")}>
          Lưu cấu trúc màn hình đang mở…
        </button>
        <button css={btn} disabled={busy} onClick={() => save(exportCss(), "map3d-css", "css")}>
          Lưu toàn bộ CSS…
        </button>
        <button
          css={btn}
          disabled={busy}
          onClick={() => save(exportHtml({ stripValues, stripScripts }), "map3d-page", "html")}
        >
          Lưu HTML trang đang mở…
        </button>
        <button css={btn} disabled={busy} onClick={() => save(exportEnvironment({ trangThai: stores() }), "map3d-env", "json")}>
          Lưu thông tin thiết bị & trạng thái…
        </button>
        <Toggle
          label="Ẩn giá trị trong ô nhập"
          value={stripValues}
          onChange={(v) => {
            setStripValues(v);
            writeBool("map3dStripValues", v);
          }}
        />
        <Toggle
          label="Bỏ mã script nội tuyến"
          value={stripScripts}
          onChange={(v) => {
            setStripScripts(v);
            writeBool("map3dStripScripts", v);
          }}
        />
        <p css={footnote}>
          Mở màn hình cần xem (chọn vùng, xem 3D…) trước khi lưu. Cảnh 3D là canvas WebGL nên chỉ
          có kích thước, không có chi tiết bên trong.
        </p>

        <p css={sectionTitle}>Tải địa chỉ</p>
        <input
          value={path}
          onChange={(e) => setPath(e.target.value)}
          placeholder="https://… hoặc /đường-dẫn"
          autoCapitalize="none"
          autoCorrect="off"
          css={css({
            width: "100%",
            boxSizing: "border-box",
            border: `1px solid ${BORDER_COLOR}`,
            borderRadius: "12px",
            padding: "0.6rem 0.8rem",
            fontSize: "0.9rem",
          })}
        />
        <button
          css={btn}
          disabled={busy}
          onClick={() =>
            run(async () => {
              const text = await fetchUrlText(path);
              await saveText(text, "map3d-fetch", "txt");
            })
          }
        >
          Tải nội dung địa chỉ và lưu file…
        </button>
        <p css={footnote}>Tải bằng GET; địa chỉ khác domain có thể bị CORS chặn.</p>

        {msg && (
          <p
            css={css({
              margin: "0.4rem 0 0",
              padding: "0.6rem 0.8rem",
              borderRadius: "12px",
              background: "#0e9aa71a",
              color: INK,
              fontSize: "0.85rem",
              whiteSpace: "pre-wrap",
            })}
          >
            {msg}
          </p>
        )}
      </Column>
    </div>
  );
}
