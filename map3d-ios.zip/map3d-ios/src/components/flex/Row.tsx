import { css } from "@emotion/react";
import { Properties } from "csstype";

export function Row({
  children,
  gap = "0.25rem",
  justify = "unset",
  overflow = "visible",
  wrap = false,
}: {
  children?: React.ReactNode;
  gap?: string;
  justify?: string;
  overflow?: Properties["overflow"];
  wrap?: boolean;
}) {
  return (
    <div
      css={css({
        display: "flex",
        flexDirection: "row",
        gap: gap,
        justifyContent: justify,
        overflow: overflow,
        flexWrap: wrap ? "wrap" : "nowrap",
      })}
    >
      {children}
    </div>
  );
}
