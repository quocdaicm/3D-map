import { useEffect, useRef, useState } from "react";
import { css } from "@emotion/react";
import {
  CircleMinus,
  LocateFixed,
  MousePointerClick,
  Search,
} from "lucide-react";
import { Geolocation } from "@capacitor/geolocation";
import { INK, PRIMARY } from "@/theme/color";
import { loadGoogleMaps } from "@/utils/googleMaps";

const IconSize = css({ width: "14px", height: "14px" });

type LatLng = { lat: number; lng: number };

// Web Mercator: lat <-> trục y chuẩn hóa
const mercY = (lat: number) => {
  const s = Math.sin((Math.max(-85, Math.min(85, lat)) * Math.PI) / 180);
  return Math.log((1 + s) / (1 - s)) / 2;
};
const invMercY = (y: number) =>
  (Math.atan(Math.sinh(y)) * 180) / Math.PI;

/**
 * Chọn vùng trên Google Maps. Cùng giao diện với bản Leaflet:
 * onDone([đông-bắc, tây-nam]) với {lat, lng}.
 */
export function GoogleMapComponent({
  onDone,
  onRemove,
  onFail,
}: {
  onDone: (e: LatLng[]) => void;
  onRemove: () => void;
  onFail: (reason: string) => void;
}) {
  const hostRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const rectRef = useRef<any>(null);
  const geocoderRef = useRef<any>(null);
  const startRef = useRef<LatLng | null>(null);

  const [ready, setReady] = useState(false);
  const [isDrag, setIsDrag] = useState(true);
  const [hasBounds, setHasBounds] = useState(false);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState<"" | "search" | "gps">("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        await loadGoogleMaps();
        const g = (window as any).google.maps;
        const { Map, Rectangle } = await g.importLibrary("maps");
        const { Geocoder } = await g.importLibrary("geocoding");
        if (cancelled || !hostRef.current) return;
        mapRef.current = new Map(hostRef.current, {
          center: { lat: 40.8, lng: -73.95 },
          zoom: 13,
          mapTypeId: "roadmap",
          mapTypeControl: true,
          streetViewControl: false,
          fullscreenControl: false,
          rotateControl: false,
          tilt: 0,
          heading: 0,
          gestureHandling: "greedy",
          clickableIcons: false,
        });
        rectRef.current = new Rectangle({
          map: null,
          strokeColor: "#1d4ed8",
          strokeWeight: 2,
          fillColor: "#3b82f6",
          fillOpacity: 0.15,
          clickable: false,
        });
        geocoderRef.current = new Geocoder();
        setReady(true);
      } catch (e: any) {
        if (!cancelled) onFail(e?.message || "Không khởi tạo được Google Maps");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Pixel trong khung bản đồ -> tọa độ (bản đồ luôn hướng bắc, không nghiêng)
  const pointToLatLng = (clientX: number, clientY: number): LatLng | null => {
    const host = hostRef.current;
    const map = mapRef.current;
    const b = map?.getBounds();
    if (!host || !b) return null;
    const r = host.getBoundingClientRect();
    const fx = Math.min(1, Math.max(0, (clientX - r.left) / r.width));
    const fy = Math.min(1, Math.max(0, (clientY - r.top) / r.height));
    const ne = b.getNorthEast();
    const sw = b.getSouthWest();
    let west = sw.lng();
    let east = ne.lng();
    if (east < west) east += 360;
    let lng = west + fx * (east - west);
    lng = ((((lng + 180) % 360) + 360) % 360) - 180;
    const yN = mercY(ne.lat());
    const yS = mercY(sw.lat());
    const lat = invMercY(yN + fy * (yS - yN));
    return { lat, lng };
  };

  const emit = (a: LatLng, b: LatLng) => {
    const north = Math.max(a.lat, b.lat);
    const south = Math.min(a.lat, b.lat);
    const east = Math.max(a.lng, b.lng);
    const west = Math.min(a.lng, b.lng);
    rectRef.current?.setOptions({
      map: mapRef.current,
      bounds: { north, south, east, west },
    });
    setHasBounds(true);
    onDone([
      { lat: north, lng: east },
      { lat: south, lng: west },
    ]);
  };

  const onPointerDown = (e: React.PointerEvent) => {
    const p = pointToLatLng(e.clientX, e.clientY);
    if (!p) return;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    startRef.current = p;
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!startRef.current) return;
    const p = pointToLatLng(e.clientX, e.clientY);
    if (p) emit(startRef.current, p);
  };
  const onPointerUp = (e: React.PointerEvent) => {
    if (!startRef.current) return;
    const p = pointToLatLng(e.clientX, e.clientY);
    if (p) emit(startRef.current, p);
    startRef.current = null;
  };

  const handleSearch = async () => {
    const q = query.trim();
    if (!q || !geocoderRef.current) return;
    setBusy("search");
    setMessage("");
    try {
      const res = await geocoderRef.current.geocode({ address: q });
      const first = res.results?.[0];
      if (!first) {
        setMessage("Không tìm thấy địa điểm này.");
      } else if (first.geometry.viewport) {
        mapRef.current.fitBounds(first.geometry.viewport);
      } else {
        mapRef.current.setCenter(first.geometry.location);
        mapRef.current.setZoom(16);
      }
    } catch (e: any) {
      const zero = String(e?.code || e?.message || "").includes("ZERO_RESULTS");
      setMessage(
        zero
          ? "Không tìm thấy địa điểm này."
          : "Không tìm được địa điểm. Kiểm tra mạng, hoặc API Geocoding chưa được bật cho key."
      );
    } finally {
      setBusy("");
    }
  };

  const handleLocate = async () => {
    if (!mapRef.current) return;
    setBusy("gps");
    setMessage("");
    try {
      const pos = await Geolocation.getCurrentPosition({
        enableHighAccuracy: true,
        timeout: 15000,
      });
      mapRef.current.setCenter({
        lat: pos.coords.latitude,
        lng: pos.coords.longitude,
      });
      mapRef.current.setZoom(17);
    } catch (e) {
      setMessage(
        "Không lấy được vị trí. Hãy cho phép truy cập vị trí trong Cài đặt."
      );
    } finally {
      setBusy("");
    }
  };

  const handleClickRemoveBox = () => {
    rectRef.current?.setMap(null);
    setHasBounds(false);
    setIsDrag(true);
    onRemove();
  };

  const iconBtn = css({
    border: "none",
    borderRadius: "12px",
    width: "44px",
    height: "44px",
    flexShrink: 0,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    backgroundColor: "#ffffff",
    color: INK,
    boxShadow: "0 4px 14px rgba(11,31,46,0.12)",
    ":disabled": { opacity: 0.5 },
  });

  return (
    <div css={css({ position: "relative" })}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSearch();
        }}
        css={css({ display: "flex", gap: "0.5rem", marginBottom: "0.6rem" })}
      >
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Tìm địa chỉ, đường, địa điểm..."
          enterKeyHint="search"
          css={css({
            flex: 1,
            minWidth: 0,
            height: "44px",
            border: "none",
            borderRadius: "12px",
            padding: "0 1rem",
            fontSize: "16px",
            color: INK,
            backgroundColor: "#ffffff",
            boxShadow: "0 4px 14px rgba(11,31,46,0.12)",
            outline: "none",
            userSelect: "text",
            WebkitUserSelect: "text",
            ":focus": { boxShadow: `0 0 0 2px ${PRIMARY}` },
          })}
        />
        <button
          type="submit"
          css={iconBtn}
          disabled={busy !== "" || !ready}
          aria-label="Tìm"
        >
          <Search size={18} />
        </button>
        <button
          type="button"
          css={iconBtn}
          disabled={busy !== "" || !ready}
          onClick={handleLocate}
          aria-label="Vị trí của tôi"
        >
          <LocateFixed size={18} color={PRIMARY} />
        </button>
      </form>
      {message && (
        <div
          css={css({
            color: "#b42318",
            fontSize: "0.85rem",
            marginBottom: "0.5rem",
          })}
        >
          {message}
        </div>
      )}

      <div
        css={css({
          position: "absolute",
          zIndex: 5,
          right: "0.7rem",
          top: "4.4rem",
          display: "flex",
          gap: "0.5rem",
        })}
      >
        <button
          css={css({
            display: hasBounds && !isDrag ? "flex" : "none",
            color: "#ffffff",
            backgroundColor: "#ef4444",
            border: "none",
            padding: "0.65rem 1rem",
            fontWeight: 600,
            fontSize: "14px",
            boxShadow: "0 6px 20px rgba(11,31,46,0.18)",
            borderRadius: "12px",
            cursor: "pointer",
            alignItems: "center",
            gap: "0.5rem",
          })}
          onClick={handleClickRemoveBox}
        >
          <CircleMinus css={IconSize} /> Xóa vùng chọn
        </button>
        <button
          css={css({
            color: isDrag ? "#ffffff" : "#000000",
            backgroundColor: isDrag ? "#0e9aa7" : "#ffffffd9",
            border: "none",
            padding: "0.65rem 1rem",
            fontWeight: 600,
            fontSize: "14px",
            boxShadow: "0 6px 20px rgba(11,31,46,0.18)",
            borderRadius: "12px",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: "0.5rem",
          })}
          onClick={() => setIsDrag(!isDrag)}
        >
          {isDrag ? (
            <>
              <MousePointerClick css={IconSize} />
              <span>Chọn vùng</span>
            </>
          ) : (
            "Di chuyển bản đồ"
          )}
        </button>
      </div>

      <div
        css={css({
          position: "relative",
          height: "calc(100vh - 24rem)",
          minHeight: "320px",
          width: "100%",
          borderRadius: "20px",
          overflow: "hidden",
          boxShadow: "0 8px 28px rgba(11,31,46,0.16)",
          background: "#e5e9ec",
        })}
      >
        <div ref={hostRef} css={css({ position: "absolute", inset: 0 })} />
        {!isDrag && ready && (
          // Lớp bắt thao tác vẽ khung; che bản đồ nên không bị kéo/zoom khi đang vẽ
          <div
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
            css={css({
              position: "absolute",
              inset: 0,
              zIndex: 2,
              touchAction: "none",
              cursor: "crosshair",
            })}
          />
        )}
      </div>

      <div
        css={css({
          marginTop: "0.7rem",
          fontSize: "0.9rem",
          lineHeight: 1.45,
          color: hasBounds ? "#0b7c87" : isDrag ? "#5a6b78" : "#0b1f2e",
          fontWeight: hasBounds || !isDrag ? 600 : 400,
        })}
      >
        {hasBounds
          ? "Đã chọn vùng. Bấm “Tiếp tục” để tải dữ liệu tòa nhà."
          : isDrag
          ? "Di chuyển và phóng to bản đồ tới khu vực cần dựng, rồi bấm nút “Chọn vùng”."
          : "Dùng ngón tay kéo trên bản đồ để vẽ khung chữ nhật quanh khu vực cần dựng."}
      </div>
    </div>
  );
}
