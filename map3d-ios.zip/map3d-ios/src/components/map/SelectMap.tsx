import React, { useEffect, useRef, useState } from "react";
import {
  MapContainer,
  LayersControl,
  Rectangle,
  TileLayer,
  useMapEvents,
} from "react-leaflet";
import L, { LatLng, LatLngBounds } from "leaflet";
import "leaflet/dist/leaflet.css";
import { css } from "@emotion/react";
import {
  CircleMinus,
  LocateFixed,
  MousePointerClick,
  Search,
} from "lucide-react";
import { Geolocation } from "@capacitor/geolocation";
import { INK, PRIMARY } from "@/theme/color";
import { GOOGLE_MAPS_KEY } from "@/utils/googleMaps";
import { GoogleMapComponent } from "./GoogleSelectMap";

const IconSize = css({
  width: "14px",
  height: "14px",
});

/** Tìm địa điểm miễn phí, không cần key: Photon (Komoot) trước, lỗi/không ra thì thử Nominatim. */
async function searchPlace(q: string): Promise<{ lat: number; lng: number } | null> {
  try {
    const res = await fetch(
      `https://photon.komoot.io/api/?limit=1&q=${encodeURIComponent(q)}`
    );
    if (res.ok) {
      const data = await res.json();
      const c = data?.features?.[0]?.geometry?.coordinates;
      if (c && c.length >= 2) return { lat: c[1], lng: c[0] };
    }
  } catch (e) {
    console.error("Photon", e);
  }
  const res = await fetch(
    `https://nominatim.openstreetmap.org/search?format=json&limit=1&accept-language=vi&q=${encodeURIComponent(
      q
    )}`
  );
  if (!res.ok) throw new Error("HTTP " + res.status);
  const data = await res.json();
  if (!data.length) return null;
  return { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) };
}

function RectangleSelector({
  isDrag = true,

  bounds,
  drawBounds,

  onChange,
  onDrawChange,
}: {
  isDrag: boolean;

  bounds: LatLngBounds | null;
  drawBounds: LatLngBounds | null;

  onChange: (bounds: LatLngBounds) => void;
  onDrawChange: (bounds: LatLngBounds) => void;
}) {
  const [firstPoint, setFirstPoint] = useState<LatLng | null>(null);

  const lastLatlngRef = useRef<LatLng | null>(null);

  const adjustLng = (latlng: LatLng): LatLng => {
    const adjustedLng = ((((latlng.lng + 180) % 360) + 360) % 360) - 180;
    return new L.LatLng(latlng.lat, adjustedLng);
  };

  const map = useMapEvents({
    mousedown(e) {
      if (!isDrag) {
        setFirstPoint(e.latlng);
      }
    },
    mousemove(e) {
      if (firstPoint) {
        lastLatlngRef.current = adjustLng(e.latlng);
        onDrawChange(new L.LatLngBounds(firstPoint, e.latlng));
        onChange(
          new L.LatLngBounds(adjustLng(firstPoint), adjustLng(e.latlng))
        );
      }
    },
    mouseup(e) {
      if (firstPoint) {
        onDrawChange(new L.LatLngBounds(firstPoint, e.latlng));
        onChange(
          new L.LatLngBounds(adjustLng(firstPoint), adjustLng(e.latlng))
        );
        setFirstPoint(null);
      }
    },
  });

  useEffect(() => {
    const container = map.getContainer();
    const handleTouchStart = (e: TouchEvent) => {
      if (!isDrag && e.touches.length > 0) {
        const touch = e.touches[0];
        const latlng = map.mouseEventToLatLng(touch as any);
        setFirstPoint(latlng);
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (firstPoint && e.touches.length > 0) {
        const touch = e.touches[0];
        const latlng = map.mouseEventToLatLng(touch as any);
        lastLatlngRef.current = latlng;

        onDrawChange(new L.LatLngBounds(firstPoint, latlng));
        onChange(new L.LatLngBounds(adjustLng(firstPoint), adjustLng(latlng)));
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      if (firstPoint) {
        const latlng = lastLatlngRef.current || firstPoint;

        onDrawChange(new L.LatLngBounds(firstPoint, latlng));
        onChange(new L.LatLngBounds(adjustLng(firstPoint), adjustLng(latlng)));
        setFirstPoint(null);
      }
    };

    container.addEventListener("touchstart", handleTouchStart);
    container.addEventListener("touchmove", handleTouchMove);
    container.addEventListener("touchend", handleTouchEnd);

    return () => {
      container.removeEventListener("touchstart", handleTouchStart);
      container.removeEventListener("touchmove", handleTouchMove);
      container.removeEventListener("touchend", handleTouchEnd);
    };
  }, [map, isDrag, firstPoint, onChange]);

  useEffect(() => {
    if (map) {
      isDrag ? map.dragging.enable() : map.dragging.disable();
    }
  }, [isDrag, map]);

  return drawBounds ? (
    <Rectangle bounds={drawBounds} pathOptions={{ color: "blue" }} />
  ) : null;
}

function LeafletMapComponent({
  onDone,
  onRemove,
}: {
  onDone: (e) => void;
  onRemove: () => void;
}) {
  const [isDrag, setIsDrag] = useState(true);
  const [bounds, setBounds] = useState<LatLngBounds | null>(null);
  const [drawBounds, setDrawBounds] = useState<LatLngBounds | null>(null);
  const [map, setMap] = useState<L.Map | null>(null);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState<"" | "search" | "gps">("");
  const [message, setMessage] = useState("");

  const handleSearch = async () => {
    const q = query.trim();
    if (!q || !map) return;
    setBusy("search");
    setMessage("");
    try {
      const found = await searchPlace(q);
      if (!found) {
        setMessage("Không tìm thấy địa điểm này.");
      } else {
        map.flyTo([found.lat, found.lng], 16);
      }
    } catch (e) {
      setMessage("Không tìm được địa điểm. Kiểm tra kết nối mạng rồi thử lại.");
    } finally {
      setBusy("");
    }
  };

  const handleLocate = async () => {
    if (!map) return;
    setBusy("gps");
    setMessage("");
    try {
      const pos = await Geolocation.getCurrentPosition({
        enableHighAccuracy: true,
        timeout: 15000,
      });
      map.flyTo([pos.coords.latitude, pos.coords.longitude], 17);
    } catch (e) {
      setMessage(
        "Không lấy được vị trí. Hãy cho phép truy cập vị trí trong Cài đặt."
      );
    } finally {
      setBusy("");
    }
  };

  const handleClickSwitchDrag = () => {
    setIsDrag(!isDrag);
  };

  const handleClickRemoveBox = () => {
    onRemove();
    setBounds(null);
    setDrawBounds(null);
    setIsDrag(true);
  };

  const handleChangeDone = (e) => {
    setBounds(e);
    onDone([e._northEast, e._southWest]);
  };

  const handleChangeDraw = (e) => {
    setDrawBounds(e);
    onDone([e._northEast, e._southWest]);
  };

  const iconBtn = css({
    border: "none",
    borderRadius: "12px",
    width: "44px",
    height: "44px",
    flexShrink: 0,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    backgroundColor: "#ffffff",
    color: INK,
    boxShadow: "0 4px 14px rgba(11,31,46,0.12)",
    ":disabled": { opacity: 0.5 },
  });

  return (
    <div
      css={css({
        position: "relative",
      })}
    >
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSearch();
        }}
        css={css({ display: "flex", gap: "0.5rem", marginBottom: "0.6rem" })}
      >
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Tìm địa chỉ, đường, địa điểm..."
          enterKeyHint="search"
          css={css({
            flex: 1,
            minWidth: 0,
            height: "44px",
            border: "none",
            borderRadius: "12px",
            padding: "0 1rem",
            fontSize: "16px",
            color: INK,
            backgroundColor: "#ffffff",
            boxShadow: "0 4px 14px rgba(11,31,46,0.12)",
            outline: "none",
            userSelect: "text",
            WebkitUserSelect: "text",
            ":focus": { boxShadow: `0 0 0 2px ${PRIMARY}` },
          })}
        />
        <button type="submit" css={iconBtn} disabled={busy !== ""} aria-label="Tìm">
          <Search size={18} />
        </button>
        <button
          type="button"
          css={iconBtn}
          disabled={busy !== ""}
          onClick={handleLocate}
          aria-label="Vị trí của tôi"
        >
          <LocateFixed size={18} color={PRIMARY} />
        </button>
      </form>
      {message && (
        <div
          css={css({
            color: "#b42318",
            fontSize: "0.85rem",
            marginBottom: "0.5rem",
          })}
        >
          {message}
        </div>
      )}
      <div
        css={css({
          position: "absolute",
          zIndex: 9999,
          right: "1rem",
          top: "4.4rem",
          display: "flex",
          justifyContent: "flex-end",
          gap: "0.5rem",
        })}
      >
        <button
          css={css({
            display: bounds == null || isDrag == true ? "none" : "flex",
            color: "#ffffff",

            backgroundColor: "#ef4444",
            backdropFilter: "blur(8px)",
            border: "none",
            padding: "0.65rem 1rem",
            fontWeight: 600,
            fontSize: "14px",
            boxShadow: "0 6px 20px rgba(11,31,46,0.18)",
            borderRadius: "12px",
            outline: "#ef4444c2 solid 0.1rem",
            cursor: "pointer",
            transition: "0.2s",
            alignItems: "center",
            gap: "0.5rem",
            ":hover": {
              backgroundColor: "#ef4444",
            },
          })}
          onClick={handleClickRemoveBox}
        >
          <CircleMinus css={IconSize} /> Xóa vùng chọn
        </button>

        <button
          css={css({
            color: isDrag ? "#ffffff" : "#000000",

            backgroundColor: isDrag ? "#0e9aa7" : "#ffffff96",
            backdropFilter: "blur(8px)",
            border: "none",
            padding: "0.65rem 1rem",
            fontWeight: 600,
            fontSize: "14px",
            boxShadow: "0 6px 20px rgba(11,31,46,0.18)",
            borderRadius: "12px",
            outline: isDrag
              ? "#0e9aa7 solid 0.1rem"
              : "rgba(240, 240, 244, 0.51) solid 0.1rem",
            cursor: "pointer",
            transition: "0.2s",
            display: "flex",
            alignItems: "center",
            gap: "0.5rem",
            ":hover": {
              backgroundColor: isDrag ? "#0b7c87" : "#ebeef0c2",
            },
          })}
          onClick={handleClickSwitchDrag}
        >
          {isDrag ? <SelectBox /> : "Di chuyển bản đồ"}
        </button>
      </div>

      <MapContainer
        ref={setMap}
        center={[40.8, -73.95]}
        zoom={13}
        style={{
          touchAction: isDrag ? undefined : "none",
          height: "calc(100vh - 24rem)",
          minHeight: "320px",
          width: "100%",
          borderRadius: "20px",
          boxShadow: "0 8px 28px rgba(11,31,46,0.16)",
        }}
      >
        <LayersControl position="bottomright">
          <LayersControl.BaseLayer checked name="Đường phố">
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              maxZoom={19}
            />
          </LayersControl.BaseLayer>
          <LayersControl.BaseLayer name="Vệ tinh">
            <TileLayer
              attribution="Tiles &copy; Esri &mdash; Source: Esri, Maxar, Earthstar Geographics, and the GIS User Community"
              url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
              maxZoom={19}
            />
          </LayersControl.BaseLayer>
          <LayersControl.BaseLayer name="Địa hình">
            <TileLayer
              attribution='Map data: &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, SRTM | Style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a> (CC-BY-SA)'
              url="https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png"
              maxZoom={17}
            />
          </LayersControl.BaseLayer>
        </LayersControl>
        <RectangleSelector
          bounds={bounds}
          drawBounds={drawBounds}
          isDrag={isDrag}
          onChange={handleChangeDone}
          onDrawChange={handleChangeDraw}
        />
      </MapContainer>
      <div
        css={css({
          marginTop: "0.7rem",
          fontSize: "0.9rem",
          lineHeight: 1.45,
          color: bounds
            ? "#0b7c87"
            : isDrag
            ? "#5a6b78"
            : "#0b1f2e",
          fontWeight: bounds || !isDrag ? 600 : 400,
        })}
      >
        {bounds
          ? "Đã chọn vùng. Bấm “Tiếp tục” để tải dữ liệu tòa nhà."
          : isDrag
          ? "Di chuyển và phóng to bản đồ tới khu vực cần dựng, rồi bấm nút “Chọn vùng”."
          : "Dùng ngón tay kéo trên bản đồ để vẽ khung chữ nhật quanh khu vực cần dựng."}
      </div>
    </div>
  );
}

function SelectBox() {
  return (
    <>
      <MousePointerClick css={IconSize} />
      <span>Chọn vùng</span>
    </>
  );
}

/**
 * Có Google Maps API key → dùng Google Maps; không có (hoặc Google lỗi) → quay về OpenStreetMap.
 */
export function MapComponent({
  onDone,
  onRemove,
}: {
  onDone: (e) => void;
  onRemove: () => void;
}) {
  const [googleError, setGoogleError] = useState("");

  if (GOOGLE_MAPS_KEY && !googleError) {
    return (
      <GoogleMapComponent
        onDone={onDone}
        onRemove={onRemove}
        onFail={setGoogleError}
      />
    );
  }
  return (
    <>
      {googleError && (
        <div
          css={css({
            color: "#b42318",
            fontSize: "0.85rem",
            marginBottom: "0.5rem",
          })}
        >
          Google Maps không dùng được ({googleError}). Đang dùng bản đồ OpenStreetMap.
        </div>
      )}
      <LeafletMapComponent onDone={onDone} onRemove={onRemove} />
    </>
  );
}
