import { css } from "@emotion/react";
import { Trash2 } from "lucide-react";
import { HistoryItem } from "@/utils/history";
import { INK, DESC_COLOR } from "@/theme/color";

export function History({
  items,
  onOpen,
  onRemove,
}: {
  items: HistoryItem[];
  onOpen: (item: HistoryItem) => void;
  onRemove: (item: HistoryItem) => void;
}) {
  if (!items.length) return null;
  return (
    <div css={css({ marginTop: "1.25rem" })}>
      <div css={css({ fontWeight: 700, color: INK, marginBottom: "0.6rem" })}>
        Vùng đã tải gần đây
      </div>
      <div css={css({ display: "flex", flexDirection: "column", gap: "0.5rem" })}>
        {items.map((item) => (
          <div
            key={item.id}
            css={css({
              display: "flex",
              alignItems: "center",
              backgroundColor: "#ffffff",
              borderRadius: "14px",
              boxShadow: "0 4px 14px rgba(11,31,46,0.08)",
              overflow: "hidden",
            })}
          >
            <button
              onClick={() => onOpen(item)}
              css={css({
                flex: 1,
                textAlign: "left",
                border: "none",
                background: "none",
                padding: "0.8rem 1rem",
                cursor: "pointer",
              })}
            >
              <div css={css({ fontWeight: 600, color: INK, fontSize: "0.95rem" })}>
                {item.name}
              </div>
              <div css={css({ color: DESC_COLOR, fontSize: "0.8rem", marginTop: "0.15rem" })}>
                {item.count} tòa nhà · {new Date(item.date).toLocaleString("vi-VN")}
              </div>
            </button>
            <button
              onClick={() => onRemove(item)}
              aria-label="Xóa"
              css={css({
                border: "none",
                background: "none",
                padding: "0 1rem",
                height: "100%",
                cursor: "pointer",
                color: "#b42318",
              })}
            >
              <Trash2 size={18} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
