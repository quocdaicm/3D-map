import { css, keyframes } from "@emotion/react";
import { Loader2 } from "lucide-react";

export interface Building {
  id: number;
  tags: { [key: string]: string | undefined };
  geometry?: { lat: number; lng: number }[];
}

const spinAnimation = keyframes`
from { transform: rotate(0deg); }
to { transform: rotate(360deg); }
`;

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div
      css={css({
        flex: 1,
        minWidth: "7rem",
        backgroundColor: "#ffffff",
        borderRadius: "18px",
        padding: "1rem 1.1rem",
        boxShadow: "0 6px 22px rgba(11,31,46,0.08)",
      })}
    >
      <div css={css({ fontSize: "1.7rem", fontWeight: 700, color: "#0b1f2e" })}>
        {value}
      </div>
      <div css={css({ fontSize: "0.8rem", color: "#5a6b78", marginTop: "0.15rem" })}>
        {label}
      </div>
    </div>
  );
}

export function BuildingHeights({
  buildings,
  loading,
  error,
}: {
  buildings: Building[];
  loading: boolean;
  error?: string | null;
}) {
  const withHeight = buildings.filter((b) => {
    const h = parseFloat(String(b.tags?.height ?? ""));
    return !isNaN(h);
  });
  const heights = withHeight.map((b) => parseFloat(String(b.tags.height)));
  const avg = heights.length
    ? (heights.reduce((a, c) => a + c, 0) / heights.length).toFixed(1)
    : "–";
  const max = heights.length ? Math.max(...heights).toFixed(0) : "–";

  return (
    <div css={css({ marginTop: "0.75rem" })}>
      {loading && (
        <div
          css={css({
            display: "flex",
            alignItems: "center",
            gap: "0.6rem",
            color: "#0b7c87",
            fontWeight: 600,
            padding: "1rem 0",
          })}
        >
          <Loader2
            css={css({ animation: `${spinAnimation} 1s linear infinite` })}
            size={18}
          />
          Đang tải dữ liệu tòa nhà...
        </div>
      )}
      {!loading && error && (
        <div
          css={css({
            backgroundColor: "#fef3f2",
            color: "#b42318",
            borderRadius: "14px",
            padding: "0.9rem 1rem",
            fontSize: "0.9rem",
            lineHeight: 1.45,
            whiteSpace: "pre-line",
            userSelect: "text",
            WebkitUserSelect: "text",
          })}
        >
          {error}
        </div>
      )}
      {!loading && buildings.length > 0 && (
        <div css={css({ display: "flex", gap: "0.75rem", flexWrap: "wrap" })}>
          <Stat label="Tòa nhà" value={buildings.length} />
          <Stat label="Có dữ liệu chiều cao" value={withHeight.length} />
          <Stat label="Cao trung bình (m)" value={avg} />
          <Stat label="Cao nhất (m)" value={max} />
        </div>
      )}
      {!loading && buildings.length > 0 && (
        <p css={css({ color: "#5a6b78", fontSize: "0.85rem", marginTop: "1rem" })}>
          Tòa nhà thiếu dữ liệu chiều cao sẽ dùng chiều cao mặc định. Nhấn
          “Xem 3D” để dựng mô hình.
        </p>
      )}
    </div>
  );
}
