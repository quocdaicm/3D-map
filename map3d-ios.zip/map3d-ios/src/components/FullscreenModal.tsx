import { css } from "@emotion/react";
import React from "react";
import { SAFE_TOP } from "@/theme/color";

export function FullscreenModal({
  children,
  isOpen = false,
}: {
  children: React.ReactNode;
  isOpen?: boolean;
}) {
  return (
    <div
      css={css({
        width: "100%",
        height: "100%",
        position: "fixed",
        zIndex: 999,
        background:
          "linear-gradient(180deg, #f4f9fb 0%, #e3eef3 100%)",
        display: isOpen ? "flex" : "none",
        overflowY: "auto",
      })}
    >
      <div
        css={css({
          padding: "1.25rem",
          paddingTop: `calc(4.25rem + ${SAFE_TOP})`,
          paddingBottom: "7rem",
          width: "100%",
          boxSizing: "border-box",
          maxWidth: "960px",
          margin: "0 auto",
        })}
      >
        {children}
      </div>
    </div>
  );
}
