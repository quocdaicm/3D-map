/** Key đọc từ biến môi trường lúc build (VITE_GOOGLE_MAPS_API_KEY). Trống = dùng bản đồ OSM. */
export const GOOGLE_MAPS_KEY: string =
  (import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string | undefined)?.trim() || "";

let loading: Promise<void> | null = null;

/** Nạp Google Maps JavaScript API một lần (không cần thêm gói npm). */
export function loadGoogleMaps(): Promise<void> {
  if (!GOOGLE_MAPS_KEY) return Promise.reject(new Error("Chưa có Google Maps API key"));
  if (loading) return loading;

  loading = new Promise<void>((resolve, reject) => {
    const w = window as any;
    if (w.google?.maps?.importLibrary) {
      resolve();
      return;
    }
    // Google gọi hàm này khi key bị từ chối (sai key, chưa bật API, chưa bật billing...)
    w.gm_authFailure = () => {
      loading = null;
      reject(new Error("Google từ chối API key"));
    };
    w.__map3dGoogleReady = () => resolve();
    const script = document.createElement("script");
    script.src =
      "https://maps.googleapis.com/maps/api/js" +
      `?key=${encodeURIComponent(GOOGLE_MAPS_KEY)}` +
      "&v=weekly&language=vi&loading=async&callback=__map3dGoogleReady";
    script.async = true;
    script.onerror = () => {
      loading = null;
      reject(new Error("Không tải được Google Maps (kiểm tra mạng)"));
    };
    document.head.appendChild(script);
  });
  return loading;
}
