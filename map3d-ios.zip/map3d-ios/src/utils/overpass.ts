const SERVERS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
  "https://overpass.private.coffee/api/interpreter",
];

const cache = new Map<string, any>();

/** Gọi Overpass, thử lần lượt các máy chủ (mỗi máy chờ tối đa 30 giây), có cache theo truy vấn. */
export async function overpass(query: string): Promise<any> {
  if (cache.has(query)) return cache.get(query);
  let lastError: any = new Error("Không có máy chủ nào phản hồi");
  for (const server of SERVERS) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 30000);
    try {
      const res = await fetch(server, {
        method: "POST",
        body: "data=" + encodeURIComponent(query),
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        signal: controller.signal,
      });
      if (!res.ok) throw new Error("HTTP " + res.status);
      const data = await res.json();
      cache.set(query, data);
      return data;
    } catch (e) {
      lastError = e;
    } finally {
      clearTimeout(timer);
    }
  }
  throw lastError;
}
