const SERVERS = [
  "https://overpass-api.de/api/interpreter",
  "https://lz4.overpass-api.de/api/interpreter",
  "https://z.overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
  "https://overpass.private.coffee/api/interpreter",
];

const TIMEOUT_MS = 35000;
const cache = new Map<string, any>();

const host = (url: string) => url.replace(/^https:\/\//, "").split("/")[0];

const explain = (e: any): string => {
  if (e?.name === "AbortError") return "hết thời gian chờ";
  const m = String(e?.message || e || "lỗi không rõ");
  if (/load failed|failed to fetch|networkerror/i.test(m))
    return "không kết nối được hoặc máy chủ từ chối (quá tải)";
  return m;
};

/**
 * Gọi Overpass bằng GET, thử lần lượt các máy chủ và gom lỗi của từng máy.
 * Chỉ cache kết quả thành công.
 */
export async function overpass(query: string): Promise<any> {
  if (cache.has(query)) return cache.get(query);
  const errors: string[] = [];
  for (const server of SERVERS) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      const res = await fetch(
        `${server}?data=${encodeURIComponent(query)}`,
        { signal: controller.signal }
      );
      if (!res.ok) throw new Error("HTTP " + res.status);
      const data = await res.json();
      if (
        data.remark &&
        /error|timed out|out of memory|rate_limited/i.test(data.remark) &&
        !(data.elements && data.elements.length)
      ) {
        throw new Error("máy chủ báo: " + String(data.remark).slice(0, 80));
      }
      cache.set(query, data);
      return data;
    } catch (e) {
      console.error("Overpass", server, e);
      errors.push(`• ${host(server)}: ${explain(e)}`);
    } finally {
      clearTimeout(timer);
    }
  }
  const err: any = new Error(errors.join("\n"));
  err.details = errors;
  throw err;
}
