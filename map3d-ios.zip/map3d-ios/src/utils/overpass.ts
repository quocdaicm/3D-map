const SERVERS = [
  "https://overpass-api.de/api/interpreter",
  "https://lz4.overpass-api.de/api/interpreter",
  "https://z.overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
  "https://overpass.private.coffee/api/interpreter",
  // Thêm máy chủ dự phòng ở các khu vực khác (Nhật, Pháp, Nga): máy nào lỗi
  // thì bị bỏ qua, máy nào trả trước thì thắng.
  "https://overpass.osm.jp/api/interpreter",
  "https://overpass.openstreetmap.fr/api/interpreter",
  "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
];

const TIMEOUT_MS = 45000;
const STAGGER_MS = 6000;
const cache = new Map<string, any>();

const host = (url: string) => url.replace(/^https:\/\//, "").split("/")[0];

const explain = (e: any): string => {
  if (e?.name === "AbortError") return "hết thời gian chờ";
  const m = String(e?.message || e || "lỗi không rõ");
  if (/load failed|failed to fetch|networkerror/i.test(m))
    return "không kết nối được hoặc máy chủ từ chối (quá tải)";
  return m;
};

/**
 * Gọi Overpass bằng GET. Thay vì thử lần lượt từng máy chủ (một máy treo là
 * chờ cả 35 giây), app bắt đầu máy đầu tiên rồi cứ 6 giây — hoặc ngay khi một
 * máy báo lỗi — mở thêm máy kế tiếp song song. Máy nào trả kết quả đúng trước
 * thì thắng, các request còn lại bị hủy. Chỉ cache kết quả thành công.
 * onStatus: báo tiến độ ra giao diện. Mỗi lần thất bại ghi console.warn
 * (vào Nhật ký lỗi trong Tùy chọn).
 */
export async function overpass(
  query: string,
  onStatus?: (text: string) => void
): Promise<any> {
  if (cache.has(query)) return cache.get(query);

  return new Promise((resolve, reject) => {
    const errors: string[] = [];
    const controllers: AbortController[] = [];
    let started = 0;
    let finished = 0;
    let done = false;
    const t0 = Date.now();

    const status = () =>
      onStatus?.(
        `Đang hỏi máy chủ OpenStreetMap (${Math.min(started, SERVERS.length)}/${SERVERS.length} máy đã thử, ` +
          `${Math.round((Date.now() - t0) / 1000)}s)…`
      );

    const stop = () => {
      done = true;
      clearInterval(ticker);
      controllers.forEach((c) => c.abort());
    };

    const startNext = () => {
      if (done || started >= SERVERS.length) return;
      const server = SERVERS[started++];
      const controller = new AbortController();
      controllers.push(controller);
      const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
      const began = Date.now();
      status();

      fetch(`${server}?data=${encodeURIComponent(query)}`, {
        signal: controller.signal,
      })
        .then(async (res) => {
          if (!res.ok) throw new Error("HTTP " + res.status);
          const data = await res.json();
          if (
            data.remark &&
            /error|timed out|out of memory|rate_limited/i.test(data.remark) &&
            !(data.elements && data.elements.length)
          ) {
            throw new Error("máy chủ báo: " + String(data.remark).slice(0, 80));
          }
          return data;
        })
        .then((data) => {
          if (done) return;
          cache.set(query, data);
          stop();
          resolve(data);
        })
        .catch((e) => {
          if (done) return; // bị hủy vì máy khác đã thắng
          const why = explain(e);
          const secs = Math.round((Date.now() - began) / 1000);
          console.warn(`Overpass ${host(server)} lỗi sau ${secs}s: ${why}`);
          errors.push(`• ${host(server)} (${secs}s): ${why}`);
          finished++;
          if (finished >= SERVERS.length) {
            stop();
            const err: any = new Error(errors.join("\n"));
            err.details = errors;
            reject(err);
          } else {
            startNext(); // máy này hỏng → mở máy kế tiếp ngay
          }
        })
        .finally(() => clearTimeout(timer));
    };

    const ticker = setInterval(() => {
      if (done) return;
      startNext();
      status();
    }, STAGGER_MS);
    startNext();
  });
}
