import { Capacitor } from "@capacitor/core";
import { Filesystem, Directory } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";

const blobToBase64 = (blob: Blob): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error);
    reader.onloadend = () => {
      const result = reader.result as string;
      resolve(result.substring(result.indexOf(",") + 1));
    };
    reader.readAsDataURL(blob);
  });

/**
 * Lưu file: trên iOS ghi vào thư mục tạm rồi mở bảng chia sẻ
 * (Lưu vào Tệp / AirDrop / ...); trên web tải xuống như cũ.
 */
export async function saveBlob(
  blob: Blob,
  fileName: string,
  dialogTitle = "Lưu / chia sẻ file GLB"
) {
  if (Capacitor.isNativePlatform()) {
    const data = await blobToBase64(blob);
    const written = await Filesystem.writeFile({
      path: fileName,
      data,
      directory: Directory.Cache,
    });
    await Share.share({
      title: fileName,
      url: written.uri,
      dialogTitle,
    });
    return;
  }

  const link = document.createElement("a");
  link.style.display = "none";
  document.body.appendChild(link);
  link.href = URL.createObjectURL(blob);
  link.download = fileName;
  link.click();
  document.body.removeChild(link);
}

/** Lưu một đoạn văn bản thành file (dùng cho công cụ chẩn đoán). */
export function saveText(text: string, prefix: string, ext: string) {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  const stamp = `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
  const mime = ext === "json" ? "application/json" : ext === "html" ? "text/html" : "text/plain";
  return saveBlob(
    new Blob([text], { type: mime + ";charset=utf-8" }),
    `${prefix}-${stamp}.${ext}`,
    "Lưu / chia sẻ file chẩn đoán"
  );
}
