/**
 * Độ cao địa hình từ tile "Terrarium" (AWS Open Data, miễn phí, không cần key).
 * Mỗi pixel mã hóa độ cao: (R * 256 + G + B / 256) - 32768 (mét).
 */
const TILE_URL = (z: number, x: number, y: number) =>
  `https://s3.amazonaws.com/elevation-tiles-prod/terrarium/${z}/${x}/${y}.png`;

const TILE = 256;
const MAX_ZOOM = 14;
const MAX_TILES_PER_AXIS = 3;

export type Bounds = { south: number; west: number; north: number; east: number };

export type TerrainSampler = {
  /** Độ cao (mét) so với điểm thấp nhất trong vùng, >= 0 */
  heightAt: (lat: number, lng: number) => number;
  /** Chênh lệch cao nhất - thấp nhất trong vùng (mét) */
  range: number;
  /** Độ cao thực (mét so với mực nước biển) của điểm thấp nhất */
  baseElevation: number;
};

export const lngToPx = (lng: number, z: number) =>
  ((lng + 180) / 360) * Math.pow(2, z) * TILE;

export const latToPx = (lat: number, z: number) => {
  const r = (Math.max(-85.0511, Math.min(85.0511, lat)) * Math.PI) / 180;
  return (
    ((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2) *
    Math.pow(2, z) *
    TILE
  );
};

function pickZoom(b: Bounds): number {
  for (let z = MAX_ZOOM; z >= 6; z--) {
    const nx =
      Math.floor(lngToPx(b.east, z) / TILE) -
      Math.floor(lngToPx(b.west, z) / TILE) +
      1;
    const ny =
      Math.floor(latToPx(b.south, z) / TILE) -
      Math.floor(latToPx(b.north, z) / TILE) +
      1;
    if (nx <= MAX_TILES_PER_AXIS && ny <= MAX_TILES_PER_AXIS) return z;
  }
  return 6;
}

function loadTile(z: number, x: number, y: number): Promise<Float32Array> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = TILE;
        canvas.height = TILE;
        const ctx = canvas.getContext("2d", { willReadFrequently: true })!;
        ctx.drawImage(img, 0, 0);
        const px = ctx.getImageData(0, 0, TILE, TILE).data;
        const out = new Float32Array(TILE * TILE);
        for (let i = 0; i < out.length; i++) {
          out[i] = px[i * 4] * 256 + px[i * 4 + 1] + px[i * 4 + 2] / 256 - 32768;
        }
        resolve(out);
      } catch (e) {
        reject(e);
      }
    };
    img.onerror = () => reject(new Error(`Không tải được tile độ cao ${z}/${x}/${y}`));
    img.src = TILE_URL(z, x, y);
  });
}

const cache = new Map<string, TerrainSampler>();

/** Tải tile độ cao phủ vùng `b` và trả về hàm lấy độ cao theo (lat, lng). */
export async function loadTerrain(b: Bounds): Promise<TerrainSampler> {
  const key = [b.south, b.west, b.north, b.east].map((n) => n.toFixed(5)).join(",");
  const hit = cache.get(key);
  if (hit) return hit;

  const z = pickZoom(b);
  const x0 = Math.floor(lngToPx(b.west, z) / TILE);
  const x1 = Math.floor(lngToPx(b.east, z) / TILE);
  const y0 = Math.floor(latToPx(b.north, z) / TILE);
  const y1 = Math.floor(latToPx(b.south, z) / TILE);
  const cols = x1 - x0 + 1;
  const rows = y1 - y0 + 1;
  const W = cols * TILE;
  const H = rows * TILE;
  const grid = new Float32Array(W * H);

  const jobs: Promise<void>[] = [];
  for (let ty = 0; ty < rows; ty++) {
    for (let tx = 0; tx < cols; tx++) {
      jobs.push(
        loadTile(z, x0 + tx, y0 + ty).then((tile) => {
          for (let r = 0; r < TILE; r++) {
            grid.set(
              tile.subarray(r * TILE, (r + 1) * TILE),
              (ty * TILE + r) * W + tx * TILE
            );
          }
        })
      );
    }
  }
  await Promise.all(jobs);

  const raw = (lat: number, lng: number) => {
    const fx = Math.min(W - 1.001, Math.max(0, lngToPx(lng, z) - x0 * TILE));
    const fy = Math.min(H - 1.001, Math.max(0, latToPx(lat, z) - y0 * TILE));
    const ix = Math.floor(fx);
    const iy = Math.floor(fy);
    const dx = fx - ix;
    const dy = fy - iy;
    const a = grid[iy * W + ix];
    const bb = grid[iy * W + ix + 1];
    const c = grid[(iy + 1) * W + ix];
    const d = grid[(iy + 1) * W + ix + 1];
    return (a * (1 - dx) + bb * dx) * (1 - dy) + (c * (1 - dx) + d * dx) * dy;
  };

  // Quét thô để tìm thấp nhất / cao nhất trong vùng
  let lo = Infinity;
  let hi = -Infinity;
  const N = 40;
  for (let i = 0; i <= N; i++) {
    for (let j = 0; j <= N; j++) {
      const h = raw(
        b.south + ((b.north - b.south) * i) / N,
        b.west + ((b.east - b.west) * j) / N
      );
      if (h < lo) lo = h;
      if (h > hi) hi = h;
    }
  }
  if (!isFinite(lo)) {
    lo = 0;
    hi = 0;
  }

  const sampler: TerrainSampler = {
    heightAt: (lat, lng) => Math.max(0, raw(lat, lng) - lo),
    range: hi - lo,
    baseElevation: lo,
  };
  cache.set(key, sampler);
  return sampler;
}
