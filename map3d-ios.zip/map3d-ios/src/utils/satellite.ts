import { latToPx, lngToPx } from "@/utils/terrain";
import type { Bounds } from "@/utils/terrain";

export type SatSource = "esri" | "sentinel";

const SOURCES: Record<
  SatSource,
  { url: (z: number, x: number, y: number) => string; maxZoom: number; credit: string }
> = {
  esri: {
    url: (z, x, y) =>
      `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${x}`,
    maxZoom: 19,
    credit: "Ảnh: Esri, Maxar, Earthstar Geographics",
  },
  sentinel: {
    url: (z, x, y) =>
      `https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless-2020_3857/default/g/${z}/${y}/${x}.jpg`,
    maxZoom: 13,
    credit: "Sentinel-2 cloudless by EOX (CC BY-NC 4.0) — Contains modified Copernicus Sentinel data 2020",
  },
};

export const satCredit = (s: SatSource) => SOURCES[s].credit;

const TILE = 256;
const MAX_PX = 2048;

function loadImage(url: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = url;
  });
}

const cache = new Map<string, HTMLCanvasElement>();

/** Ghép tile ảnh vệ tinh phủ đúng vùng `b` thành một canvas (tối đa 2048px). */
export async function loadSatellite(b: Bounds, source: SatSource): Promise<HTMLCanvasElement> {
  const key = source + [b.south, b.west, b.north, b.east].map((n) => n.toFixed(5)).join(",");
  const hit = cache.get(key);
  if (hit) return hit;

  const src = SOURCES[source];
  let z = src.maxZoom;
  for (; z > 6; z--) {
    const w = lngToPx(b.east, z) - lngToPx(b.west, z);
    const h = latToPx(b.south, z) - latToPx(b.north, z);
    if (Math.max(w, h) <= MAX_PX) break;
  }
  const pxW = lngToPx(b.west, z);
  const pxE = lngToPx(b.east, z);
  const pxN = latToPx(b.north, z);
  const pxS = latToPx(b.south, z);
  const W = Math.max(16, Math.round(pxE - pxW));
  const H = Math.max(16, Math.round(pxS - pxN));

  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = "#9aa58f";
  ctx.fillRect(0, 0, W, H);

  const x0 = Math.floor(pxW / TILE);
  const x1 = Math.floor(pxE / TILE);
  const y0 = Math.floor(pxN / TILE);
  const y1 = Math.floor(pxS / TILE);
  const jobs: Promise<boolean>[] = [];
  for (let ty = y0; ty <= y1; ty++) {
    for (let tx = x0; tx <= x1; tx++) {
      jobs.push(
        loadImage(src.url(z, tx, ty)).then((img) => {
          if (!img) return false;
          ctx.drawImage(img, tx * TILE - pxW, ty * TILE - pxN);
          return true;
        })
      );
    }
  }
  const ok = (await Promise.all(jobs)).filter(Boolean).length;
  if (ok === 0) throw new Error("Không tải được ảnh vệ tinh");

  cache.set(key, canvas);
  return canvas;
}
