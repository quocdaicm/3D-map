import { Filesystem, Directory, Encoding } from "@capacitor/filesystem";

export type LatLng = { lat: number; lng: number };
export type HistoryItem = {
  id: string;
  name: string;
  date: number;
  count: number;
  bounds: LatLng[];
};

const INDEX = "history/index.json";
const MAX_ITEMS = 10;

async function readJson<T>(path: string, fallback: T): Promise<T> {
  try {
    const r = await Filesystem.readFile({
      path,
      directory: Directory.Data,
      encoding: Encoding.UTF8,
    });
    return JSON.parse(r.data as string) as T;
  } catch {
    return fallback;
  }
}

async function writeJson(path: string, data: unknown) {
  await Filesystem.writeFile({
    path,
    directory: Directory.Data,
    encoding: Encoding.UTF8,
    data: JSON.stringify(data),
    recursive: true,
  });
}

export const loadHistory = () => readJson<HistoryItem[]>(INDEX, []);

export const loadBuildings = (id: string) =>
  readJson<any[]>(`history/${id}.json`, []);

export async function saveHistory(bounds: LatLng[], buildings: any[]) {
  try {
    const id = Date.now().toString(36);
    const lat = ((bounds[0].lat + bounds[1].lat) / 2).toFixed(4);
    const lng = ((bounds[0].lng + bounds[1].lng) / 2).toFixed(4);
    const item: HistoryItem = {
      id,
      name: `${lat}, ${lng}`,
      date: Date.now(),
      count: buildings.length,
      bounds,
    };
    await writeJson(`history/${id}.json`, buildings);
    const list = [item, ...(await loadHistory())];
    const keep = list.slice(0, MAX_ITEMS);
    for (const old of list.slice(MAX_ITEMS)) {
      Filesystem.deleteFile({
        path: `history/${old.id}.json`,
        directory: Directory.Data,
      }).catch(() => {});
    }
    await writeJson(INDEX, keep);
    return keep;
  } catch (e) {
    console.error("Lưu lịch sử thất bại", e);
    return loadHistory();
  }
}

export async function removeHistory(id: string) {
  try {
    await Filesystem.deleteFile({
      path: `history/${id}.json`,
      directory: Directory.Data,
    }).catch(() => {});
    const list = (await loadHistory()).filter((i) => i.id !== id);
    await writeJson(INDEX, list);
    return list;
  } catch {
    return loadHistory();
  }
}
