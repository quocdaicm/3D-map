import { Haptics, ImpactStyle, NotificationType } from "@capacitor/haptics";

// Rung nhẹ; trên web hoặc thiết bị không hỗ trợ thì bỏ qua êm.
export const tap = () => Haptics.impact({ style: ImpactStyle.Light }).catch(() => {});
export const success = () =>
  Haptics.notification({ type: NotificationType.Success }).catch(() => {});
export const warn = () =>
  Haptics.notification({ type: NotificationType.Error }).catch(() => {});
