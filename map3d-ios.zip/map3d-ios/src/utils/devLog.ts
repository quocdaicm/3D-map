// devLog.ts — công cụ phát triển (tương đương "Nâng cao & công cụ phát triển" của DESM Mobile):
//  • Nhật ký lỗi (luôn ghi): window.onerror, promise bị từ chối, console.error/warn, tài nguyên không tải được
//  • Nhật ký API (bật/tắt): mọi fetch/XHR — URL, tham số, trạng thái, thời gian, phản hồi (cắt bớt)
//  • Giao diện: cấu trúc DOM, toàn bộ CSS (kể cả CSS emotion), HTML trang
//  • Gói chẩn đoán: gộp tất cả vào 1 file để gửi cho người sửa
// Chỉ lưu trong máy (localStorage); khoá/token trong URL được che.

export type NetEntry = {
  t: string; // ISO time
  method: string;
  url: string;
  status?: number;
  ok?: boolean;
  ms?: number;
  type?: string; // content-type
  size?: number; // độ dài phản hồi (ký tự)
  reqBody?: string;
  resp?: string;
  error?: string;
  via: "fetch" | "xhr";
};

export type ErrEntry = {
  t: string;
  kind: "error" | "promise" | "console.error" | "console.warn" | "resource";
  msg: string;
  stack?: string;
  where?: string;
};

const NET_ON_KEY = "map3dNetLogOn";
const NET_KEY = "map3dNetLog";
const ERR_KEY = "map3dErrLog";
const MAX_NET = 150;
const MAX_ERR = 200;
const BODY_LIMIT = 6000;

const SECRET_PARAM = /(key|token|secret|auth|pass|sig)/i;

let netOn = false;
let installed = false;
let net: NetEntry[] = [];
let errs: ErrEntry[] = [];
const listeners = new Set<() => void>();

// ---------- tiện ích ----------

const nowIso = () => new Date().toISOString();

const trunc = (s: string, n = BODY_LIMIT) =>
  s.length > n ? s.slice(0, n) + `…[cắt, tổng ${s.length} ký tự]` : s;

export function redactUrl(raw: string): string {
  try {
    const u = new URL(raw, location.href);
    u.searchParams.forEach((v, k) => {
      if (SECRET_PARAM.test(k)) u.searchParams.set(k, "***");
    });
    return u.toString();
  } catch {
    return raw;
  }
}

function safeStr(v: any): string {
  if (typeof v === "string") return v;
  if (v instanceof Error) return `${v.name}: ${v.message}`;
  try {
    return JSON.stringify(v);
  } catch {
    return String(v);
  }
}

function notify() {
  listeners.forEach((f) => {
    try {
      f();
    } catch {
      /* bỏ qua */
    }
  });
}

let saveTimer: any = null;
function persistSoon() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      localStorage.setItem(ERR_KEY, JSON.stringify(errs));
    } catch {
      /* đầy bộ nhớ: bỏ qua */
    }
    try {
      localStorage.setItem(NET_KEY, JSON.stringify(net));
    } catch {
      try {
        // đầy: lưu bản không có phản hồi
        localStorage.setItem(
          NET_KEY,
          JSON.stringify(net.map((n) => ({ ...n, resp: undefined })))
        );
      } catch {
        /* bỏ qua */
      }
    }
  }, 600);
}

function pushErr(e: Omit<ErrEntry, "t">) {
  const last = errs[errs.length - 1];
  if (last && last.msg === e.msg && last.kind === e.kind) return; // chống lặp liên tiếp
  errs.push({ t: nowIso(), ...e, msg: trunc(e.msg, 1500), stack: e.stack ? trunc(e.stack, 2500) : undefined });
  if (errs.length > MAX_ERR) errs = errs.slice(-MAX_ERR);
  persistSoon();
  notify();
}

function pushNet(e: NetEntry) {
  net.push(e);
  if (net.length > MAX_NET) net = net.slice(-MAX_NET);
  persistSoon();
  notify();
}

const isTextType = (ct: string) =>
  /json|text|xml|javascript|html|csv|x-www-form/i.test(ct || "");

// ---------- cài đặt bộ ghi ----------

export function installDevLog() {
  if (installed || typeof window === "undefined") return;
  installed = true;

  try {
    errs = JSON.parse(localStorage.getItem(ERR_KEY) || "[]");
    net = JSON.parse(localStorage.getItem(NET_KEY) || "[]");
    netOn = localStorage.getItem(NET_ON_KEY) === "1";
  } catch {
    errs = [];
    net = [];
  }

  window.addEventListener(
    "error",
    (ev: any) => {
      const target = ev?.target;
      if (target && target !== window && (target.src || target.href)) {
        pushErr({
          kind: "resource",
          msg: `Không tải được <${String(target.tagName).toLowerCase()}>`,
          where: redactUrl(target.src || target.href),
        });
        return;
      }
      pushErr({
        kind: "error",
        msg: ev?.message || "Lỗi không rõ",
        stack: ev?.error?.stack,
        where: ev?.filename ? `${ev.filename}:${ev.lineno}:${ev.colno}` : undefined,
      });
    },
    true
  );

  window.addEventListener("unhandledrejection", (ev: PromiseRejectionEvent) => {
    const r: any = ev.reason;
    pushErr({ kind: "promise", msg: safeStr(r?.message ?? r), stack: r?.stack });
  });

  (["error", "warn"] as const).forEach((lvl) => {
    const orig = console[lvl].bind(console);
    console[lvl] = (...args: any[]) => {
      try {
        const err = args.find((a) => a instanceof Error) as Error | undefined;
        pushErr({
          kind: lvl === "error" ? "console.error" : "console.warn",
          msg: args.map(safeStr).join(" "),
          stack: err?.stack,
        });
      } catch {
        /* không để bộ ghi làm hỏng app */
      }
      orig(...args);
    };
  });

  // fetch
  const origFetch = window.fetch.bind(window);
  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    if (!netOn) return origFetch(input, init);
    const t0 = performance.now();
    const url = redactUrl(
      typeof input === "string" ? input : input instanceof URL ? input.href : (input as Request).url
    );
    const method = (init?.method || (input as Request)?.method || "GET").toUpperCase();
    const entry: NetEntry = { t: nowIso(), method, url, via: "fetch" };
    if (typeof init?.body === "string") entry.reqBody = trunc(init.body, 2000);
    try {
      const res = await origFetch(input, init);
      entry.status = res.status;
      entry.ok = res.ok;
      entry.type = res.headers.get("content-type") || "";
      entry.ms = Math.round(performance.now() - t0);
      if (isTextType(entry.type)) {
        res
          .clone()
          .text()
          .then((txt) => {
            entry.size = txt.length;
            entry.resp = trunc(txt);
          })
          .catch(() => {})
          .finally(() => pushNet(entry));
      } else {
        entry.size = Number(res.headers.get("content-length")) || undefined;
        pushNet(entry);
      }
      return res;
    } catch (e: any) {
      entry.ms = Math.round(performance.now() - t0);
      entry.error = safeStr(e?.message ?? e);
      pushNet(entry);
      throw e;
    }
  };

  // XHR
  const XHR = XMLHttpRequest.prototype;
  const origOpen = XHR.open;
  const origSend = XHR.send;
  XHR.open = function (this: any, method: string, url: string | URL, ...rest: any[]) {
    this.__dev = { method: String(method).toUpperCase(), url: redactUrl(String(url)) };
    return (origOpen as any).call(this, method, url, ...rest);
  };
  XHR.send = function (this: any, body?: any) {
    const d = this.__dev;
    if (netOn && d) {
      const t0 = performance.now();
      const entry: NetEntry = { t: nowIso(), method: d.method, url: d.url, via: "xhr" };
      if (typeof body === "string") entry.reqBody = trunc(body, 2000);
      this.addEventListener("loadend", () => {
        entry.status = this.status;
        entry.ok = this.status >= 200 && this.status < 300;
        entry.ms = Math.round(performance.now() - t0);
        entry.type = this.getResponseHeader?.("content-type") || "";
        try {
          if (this.responseType === "" || this.responseType === "text") {
            const txt = String(this.responseText || "");
            entry.size = txt.length;
            if (isTextType(entry.type || "")) entry.resp = trunc(txt);
          }
        } catch {
          /* bỏ qua */
        }
        if (!this.status) entry.error = "Không kết nối được / bị chặn (CORS?)";
        pushNet(entry);
      });
    }
    return origSend.call(this, body);
  };

  window.addEventListener("pagehide", () => {
    try {
      localStorage.setItem(ERR_KEY, JSON.stringify(errs));
    } catch {
      /* bỏ qua */
    }
  });
}

// ---------- điều khiển ----------

export const isNetLogOn = () => netOn;
export function setNetLogOn(on: boolean) {
  netOn = on;
  try {
    localStorage.setItem(NET_ON_KEY, on ? "1" : "0");
  } catch {
    /* bỏ qua */
  }
  notify();
}
export const counts = () => ({ net: net.length, err: errs.length });
export function subscribe(fn: () => void) {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}
export function clearNet() {
  net = [];
  persistSoon();
  notify();
}
export function clearErrors() {
  errs = [];
  persistSoon();
  notify();
}

// ---------- xuất: API ----------

export function exportNetJson(): string {
  return JSON.stringify({ exportedAt: nowIso(), count: net.length, entries: net }, null, 2);
}

export function exportNetSummary(): string {
  if (!net.length) return "(chưa ghi request nào — bật công tắc rồi thao tác trong app)";
  const groups = new Map<string, NetEntry[]>();
  for (const n of net) {
    let key: string;
    try {
      const u = new URL(n.url);
      key = `${n.method} ${u.origin}${u.pathname}`;
    } catch {
      key = `${n.method} ${n.url}`;
    }
    (groups.get(key) || groups.set(key, []).get(key)!).push(n);
  }
  const lines: string[] = [`# Tóm tắt endpoint (${net.length} request, ${groups.size} endpoint)`, ""];
  for (const [key, list] of groups) {
    const ok = list.filter((x) => x.ok).length;
    const avg = Math.round(list.reduce((s, x) => s + (x.ms || 0), 0) / list.length);
    const statuses = [...new Set(list.map((x) => x.status ?? "ERR"))].join(",");
    lines.push(`${key}`);
    lines.push(`  số lần: ${list.length} · thành công: ${ok} · mã: ${statuses} · TB: ${avg}ms`);
    const first = list[0];
    try {
      const q = [...new URL(first.url).searchParams.keys()];
      if (q.length) lines.push(`  tham số: ${q.join(", ")}`);
    } catch {
      /* bỏ qua */
    }
    if (first.type) lines.push(`  kiểu: ${first.type}`);
    const bad = list.find((x) => x.error);
    if (bad) lines.push(`  lỗi mẫu: ${bad.error}`);
    if (first.resp) lines.push(`  phản hồi mẫu: ${trunc(first.resp, 400).replace(/\s+/g, " ")}`);
    lines.push("");
  }
  return lines.join("\n");
}

export function exportNetText(): string {
  if (!net.length) return "(chưa ghi request nào)";
  return net
    .map(
      (n) =>
        `[${n.t}] ${n.via.toUpperCase()} ${n.method} ${n.url}\n` +
        `  → ${n.status ?? "ERR"} ${n.ms ?? "?"}ms ${n.type || ""} ${n.size ?? ""}\n` +
        (n.reqBody ? `  body: ${n.reqBody}\n` : "") +
        (n.error ? `  lỗi: ${n.error}\n` : "") +
        (n.resp ? `  phản hồi: ${n.resp}\n` : "")
    )
    .join("\n");
}

// ---------- xuất: lỗi ----------

export function exportErrors(): string {
  if (!errs.length) return "(chưa có lỗi nào)";
  return errs
    .map(
      (e) =>
        `[${e.t}] ${e.kind}: ${e.msg}` +
        (e.where ? `\n  tại: ${e.where}` : "") +
        (e.stack ? `\n  ${e.stack.split("\n").slice(0, 8).join("\n  ")}` : "")
    )
    .join("\n\n");
}

// ---------- xuất: giao diện ----------

const inPanel = (el: Element) => !!(el as HTMLElement).closest?.("[data-devtools]");

export function exportDomStructure(maxNodes = 3000, maxDepth = 14): string {
  const out: string[] = [];
  let count = 0;
  const walk = (el: Element, depth: number) => {
    if (count >= maxNodes) return;
    if (inPanel(el)) return;
    const tag = el.tagName.toLowerCase();
    if (["script", "style", "link", "meta", "noscript"].includes(tag)) return;
    count++;
    const id = el.id ? `#${el.id}` : "";
    const cls =
      typeof (el as any).className === "string" && (el as any).className
        ? "." + (el as any).className.trim().split(/\s+/).slice(0, 4).join(".")
        : "";
    let extra = "";
    const r = el.getBoundingClientRect();
    if (r.width || r.height) extra += ` [${Math.round(r.x)},${Math.round(r.y)} ${Math.round(r.width)}×${Math.round(r.height)}]`;
    if (tag === "canvas") {
      const c = el as HTMLCanvasElement;
      extra += ` canvas ${c.width}×${c.height}`;
    }
    if (tag === "img") extra += ` src=${redactUrl((el as HTMLImageElement).src).slice(0, 90)}`;
    if (tag === "input" || tag === "textarea") extra += ` type=${(el as HTMLInputElement).type || ""}`;
    const txt = Array.from(el.childNodes)
      .filter((n) => n.nodeType === 3)
      .map((n) => (n.textContent || "").trim())
      .join(" ")
      .slice(0, 50);
    if (txt) extra += ` "${txt}"`;
    out.push("  ".repeat(depth) + tag + id + cls + extra);
    if (tag === "svg") return; // không đi sâu vào SVG
    if (depth >= maxDepth) {
      if (el.children.length) out.push("  ".repeat(depth + 1) + `…(${el.children.length} con)`);
      return;
    }
    for (const ch of Array.from(el.children)) walk(ch, depth + 1);
  };
  walk(document.body, 0);
  if (count >= maxNodes) out.push(`…(đã cắt ở ${maxNodes} nút)`);
  return out.join("\n");
}

export function exportCss(): string {
  const parts: string[] = [];
  Array.from(document.styleSheets).forEach((sheet, i) => {
    const owner = (sheet.ownerNode as HTMLElement | null)?.tagName?.toLowerCase();
    const head = `/* ===== stylesheet #${i} (${owner || "?"}${sheet.href ? " " + sheet.href : ""}) ===== */`;
    try {
      const rules = Array.from(sheet.cssRules).map((r) => r.cssText);
      parts.push(head + "\n" + rules.join("\n"));
    } catch {
      parts.push(head + "\n/* không đọc được (khác nguồn) */");
    }
  });
  return parts.join("\n\n");
}

export function exportHtml(opts: { stripValues: boolean; stripScripts: boolean }): string {
  const clone = document.documentElement.cloneNode(true) as HTMLElement;
  clone.querySelectorAll("[data-devtools]").forEach((n) => n.remove());
  if (opts.stripScripts) clone.querySelectorAll("script").forEach((n) => n.remove());
  if (opts.stripValues) {
    clone.querySelectorAll("input, textarea").forEach((n) => {
      n.removeAttribute("value");
      if (n.tagName === "TEXTAREA") n.textContent = "";
    });
  }
  return "<!doctype html>\n" + clone.outerHTML;
}

// ---------- chẩn đoán ----------

function limitedJson(value: any, maxArr = 20, maxDepth = 5): string {
  const seen = new WeakSet();
  const walk = (v: any, d: number): any => {
    if (typeof v === "function") return undefined;
    if (v && typeof v === "object") {
      if (seen.has(v)) return "[vòng lặp]";
      seen.add(v);
      if (d >= maxDepth) return Array.isArray(v) ? `[mảng ${v.length}]` : "[đối tượng]";
      if (Array.isArray(v)) {
        const head = v.slice(0, maxArr).map((x) => walk(x, d + 1));
        return v.length > maxArr ? [...head, `…(+${v.length - maxArr} phần tử, tổng ${v.length})`] : head;
      }
      const o: any = {};
      for (const k of Object.keys(v)) {
        const w = walk(v[k], d + 1);
        if (w !== undefined) o[k] = w;
      }
      return o;
    }
    return v;
  };
  try {
    return JSON.stringify(walk(value, 0), null, 2);
  } catch (e) {
    return "(không chuyển được: " + safeStr(e) + ")";
  }
}

function webglInfo(): string {
  try {
    const c = document.createElement("canvas");
    const gl = (c.getContext("webgl2") || c.getContext("webgl")) as WebGLRenderingContext | null;
    if (!gl) return "không có WebGL";
    const ext = gl.getExtension("WEBGL_debug_renderer_info");
    const r = ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER);
    return `${r} · maxTexture ${gl.getParameter(gl.MAX_TEXTURE_SIZE)}`;
  } catch (e) {
    return "lỗi: " + safeStr(e);
  }
}

export function exportEnvironment(extra?: Record<string, any>): string {
  const cap: any = (window as any).Capacitor;
  const perf = performance as any;
  const info: Record<string, any> = {
    thoiGian: nowIso(),
    userAgent: navigator.userAgent,
    nenTang: cap?.getPlatform?.() || "web",
    native: !!cap?.isNativePlatform?.(),
    manHinh: `${screen.width}×${screen.height} @${devicePixelRatio}x`,
    cuaSo: `${innerWidth}×${innerHeight}`,
    ngonNgu: navigator.language,
    trucTuyen: navigator.onLine,
    ketNoi: (navigator as any).connection?.effectiveType,
    boNho: perf.memory
      ? `${Math.round(perf.memory.usedJSHeapSize / 1048576)}MB / ${Math.round(perf.memory.jsHeapSizeLimit / 1048576)}MB`
      : "không hỗ trợ",
    webgl: webglInfo(),
    googleMapsKeyCoTrongBuild: !!(import.meta as any).env?.VITE_GOOGLE_MAPS_API_KEY,
    url: redactUrl(location.href),
    ...extra,
  };
  return JSON.stringify(info, null, 2);
}

export function exportResourceHosts(): string {
  const entries = performance.getEntriesByType("resource") as PerformanceResourceTiming[];
  const m = new Map<string, { n: number; bytes: number; slow: number }>();
  for (const e of entries) {
    let host = "?";
    try {
      host = new URL(e.name).host;
    } catch {
      /* bỏ qua */
    }
    const g = m.get(host) || { n: 0, bytes: 0, slow: 0 };
    g.n++;
    g.bytes += e.transferSize || 0;
    if (e.duration > 3000) g.slow++;
    m.set(host, g);
  }
  if (!m.size) return "(không có)";
  return [...m.entries()]
    .sort((a, b) => b[1].n - a[1].n)
    .map(([h, g]) => `${h}: ${g.n} tài nguyên, ${(g.bytes / 1024).toFixed(0)}KB, chậm>3s: ${g.slow}`)
    .join("\n");
}

/** Gói chẩn đoán: gộp mọi thứ để gửi 1 file. */
export function exportBundle(opts: {
  stores?: Record<string, any>;
  stripValues: boolean;
  includeHtml?: boolean;
}): string {
  const sec = (title: string, body: string) => `\n\n######## ${title} ########\n${body}`;
  let out = "MAP3D — GÓI CHẨN ĐOÁN\n";
  out += sec("MÔI TRƯỜNG", exportEnvironment());
  out += sec(`LỖI (${errs.length})`, exportErrors());
  if (opts.stores) {
    for (const [name, value] of Object.entries(opts.stores)) out += sec(`TRẠNG THÁI: ${name}`, limitedJson(value));
  }
  out += sec(`API — TÓM TẮT (${net.length} request)`, exportNetSummary());
  out += sec("MÁY CHỦ TÀI NGUYÊN (ảnh, tile, script…)", exportResourceHosts());
  out += sec("CẤU TRÚC GIAO DIỆN", exportDomStructure());
  out += sec("CSS", exportCss());
  if (opts.includeHtml) out += sec("HTML", exportHtml({ stripValues: opts.stripValues, stripScripts: true }));
  return out;
}

// ---------- tải địa chỉ ----------

export async function fetchUrlText(input: string): Promise<string> {
  const url = input.trim();
  if (!url) throw new Error("Hãy nhập địa chỉ cần tải.");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30000);
  try {
    const res = await fetch(url, { signal: controller.signal });
    const body = await res.text();
    return `GET ${redactUrl(url)}\n→ ${res.status} ${res.headers.get("content-type") || ""}\n\n${body}`;
  } catch (e: any) {
    if (e?.name === "AbortError") throw new Error("Hết thời gian chờ (30s).");
    throw new Error(
      "Không tải được: " + safeStr(e?.message ?? e) + "\n(Địa chỉ khác domain có thể bị CORS chặn trong WebView.)"
    );
  } finally {
    clearTimeout(timer);
  }
}
