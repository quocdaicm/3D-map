import { memo, useCallback, useEffect, useMemo, useState } from "react";
import type { CSSProperties } from "react";
import { Canvas, extend, ReactThreeFiber, useThree } from "@react-three/fiber";
import { useAreaStore } from "@/state/areaStore";
import { Html, Sky, Environment, Line } from "@react-three/drei";
import * as THREE from "three";
import { useActionStore } from "@/state/exportStore";
import {
  GLTFExporter,
  USDZExporter,
  OBJExporter,
  STLExporter,
} from "three/examples/jsm/Addons.js";
import Car from "./Car";
import { useCarStore } from "@/state/carStore";
import { overpass } from "@/utils/overpass";
import { saveBlob } from "@/utils/saveFile";
import { loadTerrain } from "@/utils/terrain";
import type { TerrainSampler } from "@/utils/terrain";
import { loadSatellite, satCredit } from "@/utils/satellite";
import type { SatSource } from "@/utils/satellite";

const scale = 51000;
/** Độ cao địa hình theo mét, nhân hệ số này (cùng quy ước với chiều cao tòa nhà) */
const ELEV_SCALE = 1;

const PALETTE = ["#e8d9c4", "#d9c3a5", "#cdb4a0", "#e3cfc0", "#d8d4cb", "#c9d1d6", "#efe6d2"];

/** Màu tòa nhà theo loại; không rõ loại thì chọn ổn định theo id để khu phố không bị một màu */
function buildingColor(id: number | string, tags: any): string {
  const b = tags?.building;
  if (["commercial", "retail", "office", "hotel", "supermarket"].includes(b)) return "#b7c6d6";
  if (["industrial", "warehouse", "factory"].includes(b)) return "#b0b3b8";
  if (
    ["church", "temple", "mosque", "cathedral", "pagoda", "religious", "shrine"].includes(b) ||
    tags?.amenity === "place_of_worship"
  )
    return "#e5c36b";
  if (["school", "university", "college", "kindergarten", "hospital", "civic", "public"].includes(b))
    return "#e3a698";
  let h = 0;
  for (const ch of String(id)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return PALETTE[h % PALETTE.length];
}

/** Bản sao để xuất file: trả màu gốc (bỏ màu xanh khi đang hover/click) */
function cloneForExport(child: THREE.Object3D): any {
  const c: any = child.clone(true);
  const base = child.userData?.baseColor;
  if (base && c.material) {
    c.material = c.material.clone();
    c.material.color.set(base);
  }
  return c;
}

const ROAD_WIDTH_M: Record<string, number> = {
  motorway: 14, trunk: 12, primary: 10, secondary: 8, tertiary: 7,
  residential: 5, unclassified: 5, living_street: 4, service: 3.5, track: 3,
  footway: 1.5, path: 1.5, pedestrian: 2, cycleway: 1.5, steps: 1.5,
};
const ROAD_COLOR = (h: string) =>
  ["motorway", "trunk", "primary"].includes(h)
    ? "#454a52"
    : ["secondary", "tertiary"].includes(h)
    ? "#565c64"
    : ["footway", "path", "pedestrian", "cycleway", "steps", "track"].includes(h)
    ? "#cdbd9d"
    : "#696f77";

const Building = memo(function Building({
  id,
  shape,
  depth,
  y,
  color,
  isEdited,
  tags,
  onHeightChange,
}: {
  id: number | string;
  shape: THREE.Shape;
  depth: number;
  y: number;
  color: string;
  isEdited: boolean;
  tags: any;
  onHeightChange: (id: number | string, height: number | null) => void;
}) {
  const extrudeSettings = useMemo(
    () => ({ steps: 1, depth, bevelEnabled: false }),
    [depth]
  );
  const [hovered, setHovered] = useState(false);
  const [clicked, setClicked] = useState(false);
  const [hoverPos, setHoverPos] = useState<THREE.Vector3 | null>(null);
  const [showTranslations, setShowTranslations] = useState(false);
  const [showAdditionalInfo, setShowAdditionalInfo] = useState(false);
  return (
    <mesh
      onPointerOver={(e) => {
        setHovered(true);
        e.stopPropagation();
      }}
      onPointerOut={(e) => {
        setHovered(false);
        e.stopPropagation();
      }}
      onPointerMove={(e) => {
        setHoverPos(e.point.clone());
        e.stopPropagation();
      }}
      onClick={(e) => {
        setClicked(!clicked);
        e.stopPropagation();
      }}
      position={[0, y, 0]}
      rotation={[-Math.PI / 2, 0, 0]}
      userData={{ exportToGLB: true, baseColor: color }}
    >
      <extrudeGeometry args={[shape, extrudeSettings]} />
      <meshStandardMaterial color={hovered || clicked ? "#007bff" : color} />
      {(hovered || clicked) && hoverPos && (
        <Html position={[hoverPos.x, hoverPos.y + extrudeSettings.depth + 0.5, hoverPos.z]} center>
          <div
            role="dialog"
            aria-label={tags.name || "Thông tin tòa nhà"}
            style={{
              color: "#000000",
              backgroundColor: "#ffffff96",
              backdropFilter: "blur(8px)",
              border: "none",
              padding: "14px",
              borderRadius: "10px",
              fontFamily: "system-ui, -apple-system, sans-serif",
              fontSize: "13px",
              width: "200px",
              boxShadow: "0 2px 14px rgba(0, 0, 0, 0.16)",
              transition: "all 0.2s ease-in-out",
            }}
          >
            <div
              style={{
                fontWeight: "600",
                fontSize: "15px",
                borderBottom: tags.name ? "1px solid rgba(0, 0, 0, 0.08)" : "none",
                paddingBottom: tags.name ? "6px" : "0",
                marginBottom: tags.name ? "8px" : "4px",
              }}
            >
              {tags.name || "Thông tin tòa nhà"}
            </div>
            {clicked && (
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                  margin: "6px 0 8px",
                }}
              >
                <span style={{ fontWeight: 500, color: "#5f6368", flex: 1 }}>
                  Cao (m)
                </span>
                <button
                  style={editBtn}
                  onClick={() => onHeightChange(id, Math.max(1, depth - 1))}
                >
                  −
                </button>
                <input
                  type="number"
                  inputMode="decimal"
                  value={Math.round(depth * 10) / 10}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value);
                    if (!isNaN(v) && v > 0) onHeightChange(id, v);
                  }}
                  style={{
                    width: "52px",
                    textAlign: "center",
                    border: "1px solid rgba(0,0,0,0.15)",
                    borderRadius: "8px",
                    padding: "6px 2px",
                    fontSize: "14px",
                    userSelect: "text",
                    WebkitUserSelect: "text",
                  }}
                />
                <button
                  style={editBtn}
                  onClick={() => onHeightChange(id, depth + 1)}
                >
                  +
                </button>
              </div>
            )}
            {clicked && isEdited && (
              <button
                style={{ ...editBtn, width: "100%", marginBottom: "6px" }}
                onClick={() => onHeightChange(id, null)}
              >
                Đặt lại chiều cao gốc
              </button>
            )}
            {["building", "height", "building:levels", "amenity", "denomination"].map(
              (key) =>
                tags[key] &&
                (key !== "building" || tags[key] !== "yes") && (
                  <div
                    key={key}
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      margin: "4px 0",
                    }}
                  >
                    <span style={{ fontWeight: "500", color: "#5f6368" }}>
                      {key === "building"
                        ? "Loại"
                        : key === "height"
                        ? "Chiều cao"
                        : key === "building:levels"
                        ? "Số tầng"
                        : key === "amenity"
                        ? "Tiện ích"
                        : key === "denomination"
                        ? "Giáo phái"
                        : key.replace(/_/g, " ")}
                      :
                    </span>
                    <span style={{ textTransform: "capitalize" }}>
                      {key === "height" ? `${tags[key]} m` : tags[key]}
                    </span>
                  </div>
                )
            )}
            {[
              "addr:street",
              "addr:housenumber",
              "addr:district",
              "addr:city",
              "addr:postcode",
            ].some((key) => tags[key]) && (
              <div
                style={{
                  margin: "10px 0 8px",
                  borderTop: "1px solid rgba(0, 0, 0, 0.08)",
                  paddingTop: "8px",
                }}
              >
                <div style={{ fontWeight: "500", marginBottom: "4px", color: "#5f6368" }}>
                  Địa chỉ
                </div>
                <div style={{ marginLeft: "4px", fontSize: "12px", color: "#5f6368" }}>
                  {[
                    [tags["addr:street"], tags["addr:housenumber"]].filter(Boolean).join(" "),
                    tags["addr:district"],
                    tags["addr:city"],
                    tags["addr:postcode"],
                  ]
                    .filter(Boolean)
                    .join(", ")}
                </div>
              </div>
            )}
            {Object.entries(tags).filter(
              ([key]) =>
                ![
                  "building",
                  "name",
                  "height",
                  "building:levels",
                  "source",
                  "amenity",
                  "denomination",
                ].includes(key) &&
                !key.startsWith("addr:") &&
                !key.startsWith("name:") &&
                !key.startsWith("alt_name:")
            ).length > 0 && (
              <div
                style={{
                  margin: "10px 0 4px",
                  borderTop: "1px solid rgba(0, 0, 0, 0.08)",
                  paddingTop: "8px",
                }}
              >
                <div
                  style={{
                    fontWeight: "500",
                    marginBottom: "4px",
                    color: "#5f6368",
                    cursor: "pointer",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                  onClick={() => setShowAdditionalInfo(!showAdditionalInfo)}
                >
                  Thông tin thêm
                  <span>{showAdditionalInfo ? "▲" : "▼"}</span>
                </div>
                {showAdditionalInfo && (
                  <div>
                    {Object.entries(tags)
                      .filter(
                        ([key]) =>
                          ![
                            "building",
                            "name",
                            "height",
                            "building:levels",
                            "source",
                            "amenity",
                            "denomination",
                          ].includes(key) &&
                          !key.startsWith("addr:") &&
                          !key.startsWith("name:") &&
                          !key.startsWith("alt_name:")
                      )
                      .map(([key, value]) => {
                        if (
                          key === "description" ||
                          (typeof value === "string" && value.length > 80)
                        ) {
                          return (
                            <div key={key} style={{ margin: "8px 0" }}>
                              <div
                                style={{ fontWeight: "500", color: "#5f6368", marginBottom: "4px" }}
                              >
                                {key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, " ")}
                              </div>
                              <div
                                style={{
                                  textAlign: "left",
                                  fontSize: "12px",
                                  color: "#5f6368",
                                  fontWeight: "400",
                                  textWrap: "wrap",
                                  whiteSpace: "pre-wrap",
                                  lineHeight: "1.4",
                                  backgroundColor: "rgba(0,0,0,0.02)",
                                  padding: "6px 8px",
                                  borderRadius: "4px",
                                }}
                              >
                                {String(value)}
                              </div>
                            </div>
                          );
                        }
                        return (
                          <div
                            key={key}
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              margin: "4px 0",
                            }}
                          >
                            <span
                              style={{
                                fontWeight: "700",
                                color: "#5f6368",
                                textAlign: "left",
                              }}
                            >
                              {key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, " ")}:
                            </span>
                            <span
                              style={{
                                textTransform: "capitalize",
                                fontWeight: "400",
                                textAlign: "right",
                              }}
                            >
                              {String(value)}
                            </span>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>
            )}
            {Object.entries(tags).filter(([key]) => key.startsWith("name:")).length > 0 && (
              <div
                style={{
                  margin: "10px 0 4px",
                  borderTop: "1px solid rgba(0, 0, 0, 0.08)",
                  paddingTop: "8px",
                  textAlign: "right",
                }}
              >
                <div
                  style={{
                    fontWeight: "500",
                    marginBottom: "4px",
                    color: "#5f6368",
                    cursor: "pointer",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                  onClick={() => setShowTranslations(!showTranslations)}
                >
                  Name Translations
                  <span>{showTranslations ? "▲" : "▼"}</span>
                </div>
                {showTranslations && (
                  <div>
                    {Object.entries(tags)
                      .filter(([key]) => key.startsWith("name:"))
                      .map(([key, value]) => (
                        <div
                          key={key}
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            margin: "4px 0",
                          }}
                        >
                          <span style={{ fontWeight: "500", color: "#5f6368" }}>
                            {key.replace("name:", "").toUpperCase()}:
                          </span>
                          <span style={{ textTransform: "capitalize" }}>{String(value)}</span>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </Html>
      )}
    </mesh>
  );
});

const editBtn: CSSProperties = {
  border: "none",
  borderRadius: "8px",
  background: "#0b1f2e0d",
  padding: "6px 10px",
  fontSize: "14px",
  fontWeight: 600,
  cursor: "pointer",
};

function Roads({
  area,
  terrain,
}: {
  area: any;
  terrain: TerrainSampler | null;
}) {
  const [roads, setRoads] = useState<any[]>([]);

  useEffect(() => {
    if (!area || area.length < 2) return;
    const south = area[1].lat;
    const west = area[1].lng;
    const north = area[0].lat;
    const east = area[0].lng;
    const query = `[out:json][timeout:40];(way["highway"](${south},${west},${north},${east}););out body geom;`;
    let cancelled = false;
    overpass(query)
      .then((data) => {
        if (!cancelled) setRoads(data.elements || []);
      })
      .catch((err) => console.error("Roads", err));
    return () => {
      cancelled = true;
    };
  }, [area]);

  // Dựng mặt đường thành dải mesh (xuất được ra GLB), gom theo màu
  const groups = useMemo(() => {
    if (!area || area.length < 2 || !roads.length) return [];
    const refLat = (area[1].lat + area[0].lat) / 2;
    const refLng = (area[1].lng + area[0].lng) / 2;
    const kx = scale * Math.cos((refLat * Math.PI) / 180);
    const mPerUnit = 111320 / scale;
    const buckets = new Map<string, { pos: number[]; idx: number[] }>();

    for (const road of roads) {
      const geom = road.geometry;
      if (!geom || geom.length < 2) continue;
      const hw = road.tags?.highway || "";
      const half = (ROAD_WIDTH_M[hw] ?? 4) / mPerUnit / 2;
      const color = ROAD_COLOR(hw);
      let bucket = buckets.get(color);
      if (!bucket) {
        bucket = { pos: [], idx: [] };
        buckets.set(color, bucket);
      }
      const pts = geom.map((pt: any) => ({
        x: (pt.lon - refLng) * kx,
        z: -(pt.lat - refLat) * scale,
        y: (terrain ? terrain.heightAt(pt.lat, pt.lon) * ELEV_SCALE : 0) + 0.4,
      }));
      const base = bucket.pos.length / 3;
      for (let k = 0; k < pts.length; k++) {
        const prev = pts[Math.max(0, k - 1)];
        const next = pts[Math.min(pts.length - 1, k + 1)];
        let dx = next.x - prev.x;
        let dz = next.z - prev.z;
        let len = Math.hypot(dx, dz);
        if (len === 0) {
          dx = 1;
          dz = 0;
          len = 1;
        }
        const nx = (-dz / len) * half;
        const nz = (dx / len) * half;
        const p = pts[k];
        bucket.pos.push(p.x + nx, p.y, p.z + nz, p.x - nx, p.y, p.z - nz);
        if (k > 0) {
          const i = base + (k - 1) * 2;
          bucket.idx.push(i, i + 2, i + 1, i + 1, i + 2, i + 3);
        }
      }
    }

    return Array.from(buckets.entries()).map(([color, b]) => {
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.Float32BufferAttribute(b.pos, 3));
      g.setIndex(b.idx);
      g.computeVertexNormals();
      return { color, geometry: g };
    });
  }, [roads, area, terrain]);

  return (
    <>
      {groups.map((g) => (
        <mesh key={g.color} geometry={g.geometry} userData={{ exportToGLB: true }}>
          <meshStandardMaterial color={g.color} side={THREE.DoubleSide} />
        </mesh>
      ))}
    </>
  );
}

function Terrain({
  center,
  terrain,
  satellite,
}: {
  center: { lat: number; lng: number }[];
  terrain: TerrainSampler;
  satellite: HTMLCanvasElement | null;
}) {
  const { geometry, elevCanvas } = useMemo(() => {
    const south = Math.min(center[0].lat, center[1].lat);
    const north = Math.max(center[0].lat, center[1].lat);
    const west = Math.min(center[0].lng, center[1].lng);
    const east = Math.max(center[0].lng, center[1].lng);
    const refLat = (south + north) / 2;
    const refLng = (west + east) / 2;
    const kx = scale * Math.cos((refLat * Math.PI) / 180);
    const width = (east - west) * kx;
    const height = (north - south) * scale;
    const MAX = 128;
    const nx = Math.max(8, Math.round(width >= height ? MAX : (MAX * width) / height));
    const nz = Math.max(8, Math.round(height >= width ? MAX : (MAX * height) / width));

    const positions = new Float32Array((nx + 1) * (nz + 1) * 3);
    const uvs = new Float32Array((nx + 1) * (nz + 1) * 2);
    let v = 0;
    for (let i = 0; i <= nz; i++) {
      const lat = north - ((north - south) * i) / nz;
      for (let j = 0; j <= nx; j++) {
        const lng = west + ((east - west) * j) / nx;
        positions[v * 3] = (lng - refLng) * kx;
        positions[v * 3 + 1] = terrain.heightAt(lat, lng) * ELEV_SCALE;
        positions[v * 3 + 2] = -(lat - refLat) * scale;
        uvs[v * 2] = j / nx;
        uvs[v * 2 + 1] = 1 - i / nz;
        v++;
      }
    }
    const indices: number[] = [];
    for (let i = 0; i < nz; i++) {
      for (let j = 0; j < nx; j++) {
        const a = i * (nx + 1) + j;
        const b = a + 1;
        const c = a + (nx + 1);
        const d = c + 1;
        indices.push(a, c, b, b, c, d);
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    g.setAttribute("uv", new THREE.BufferAttribute(uvs, 2));
    g.setIndex(indices);
    g.computeVertexNormals();

    // Màu theo độ cao nướng thành ảnh (hiển thị được trên mọi phần mềm, không cần vertex color)
    const TW = width >= height ? 512 : Math.max(16, Math.round((512 * width) / height));
    const TH = height >= width ? 512 : Math.max(16, Math.round((512 * height) / width));
    const canvas = document.createElement("canvas");
    canvas.width = TW;
    canvas.height = TH;
    const ctx = canvas.getContext("2d")!;
    const img = ctx.createImageData(TW, TH);
    const low = [184, 201, 163];
    const mid = [201, 184, 143];
    const high = [241, 241, 238];
    // Vùng gần như phẳng (đồng bằng) giữ màu xanh, không bị nhiễu màu
    const range = Math.max(terrain.range, 20);
    for (let y = 0; y < TH; y++) {
      const lat = north - ((north - south) * y) / (TH - 1);
      for (let x = 0; x < TW; x++) {
        const lng = west + ((east - west) * x) / (TW - 1);
        const t = Math.min(1, terrain.heightAt(lat, lng) / range);
        const [from, to, k] = t < 0.5 ? [low, mid, t * 2] : [mid, high, (t - 0.5) * 2];
        const o = (y * TW + x) * 4;
        img.data[o] = from[0] + (to[0] - from[0]) * k;
        img.data[o + 1] = from[1] + (to[1] - from[1]) * k;
        img.data[o + 2] = from[2] + (to[2] - from[2]) * k;
        img.data[o + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
    return { geometry: g, elevCanvas: canvas };
  }, [center, terrain]);

  // Ảnh vệ tinh (nếu có) hoặc màu theo độ cao
  const texture = useMemo(() => {
    const tex = new THREE.CanvasTexture(satellite ?? elevCanvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 4;
    if (satellite) tex.userData.mimeType = "image/jpeg"; // file GLB nhẹ hơn
    return tex;
  }, [satellite, elevCanvas]);

  // Hạ nhẹ để chân tòa nhà và đường không bị lún/chớp mặt phẳng
  return (
    <mesh geometry={geometry} position={[0, -0.05, 0]} userData={{ exportToGLB: true }}>
      <meshStandardMaterial map={texture} />
    </mesh>
  );
}

export function Export() {
  const { scene } = useThree();
  const action = useActionStore((state) => state.action);

  const exportType = useActionStore((state) => state.exportType);

  const setAction = useActionStore((state) => state.setAction);

  useEffect(() => {
    if (action === true) {
      setAction(false);
      if (exportType === "usdz") {
        exportUSDZ();
      } else if (exportType === "obj" || exportType === "stl") {
        exportMesh(exportType);
      } else {
        exportGLB();
      }
    }
  }, [action, setAction, scene]);

  const exportMesh = async (type: "obj" | "stl") => {
    try {
      const root = new THREE.Group();
      scene.traverse((child) => {
        if (child.userData?.exportToGLB === true) {
          const c: any = cloneForExport(child);
          if (c.isMesh && c.material?.isMeshStandardMaterial) root.add(c);
        }
      });
      if (root.children.length === 0) {
        throw new Error("Không có mô hình để xuất");
      }
      root.updateMatrixWorld(true);
      if (type === "obj") {
        const text = new OBJExporter().parse(root);
        await saveBlob(new Blob([text], { type: "text/plain" }), "map3d.obj");
      } else {
        const view = new STLExporter().parse(root, { binary: true });
        await saveBlob(
          new Blob([view as any], { type: "model/stl" }),
          "map3d.stl"
        );
      }
    } catch (error) {
      console.error("Export failed", error);
      alert("Xuất file thất bại: " + (error as Error).message);
    }
  };

  const exportUSDZ = async () => {
    try {
      const root = new THREE.Group();
      scene.traverse((child) => {
        if (child.userData?.exportToGLB === true) {
          const c: any = cloneForExport(child);
          // USDZ chỉ hỗ trợ mesh với vật liệu Standard (bỏ đường kẻ/đường đi)
          if (c.isMesh && c.material?.isMeshStandardMaterial) {
            root.add(c);
          }
        }
      });
      if (root.children.length === 0) {
        throw new Error("Không có mô hình để xuất");
      }
      // Thu nhỏ về cỡ mặt bàn (~50 cm) để xem AR, đặt đáy chạm sàn
      const box = new THREE.Box3().setFromObject(root);
      const size = box.getSize(new THREE.Vector3());
      const maxDim = Math.max(size.x, size.y, size.z) || 1;
      const k = 0.5 / maxDim;
      const wrapper = new THREE.Group();
      wrapper.add(root);
      root.position.set(
        -(box.min.x + box.max.x) / 2,
        -box.min.y,
        -(box.min.z + box.max.z) / 2
      );
      wrapper.scale.setScalar(k);
      wrapper.updateMatrixWorld(true);

      const exporter: any = new USDZExporter();
      const data: Uint8Array = await (exporter.parseAsync
        ? exporter.parseAsync(wrapper)
        : exporter.parse(wrapper));
      const blob = new Blob([data], { type: "model/vnd.usdz+zip" });
      await saveBlob(blob, "map3d.usdz");
    } catch (error) {
      console.error("USDZ export failed", error);
      alert("Xuất USDZ thất bại: " + (error as Error).message);
    }
  };

  const exportGLB = () => {
    const exportRoot = new THREE.Group();
    scene.traverse((child) => {
      if (child.userData?.exportToGLB === true) {
        exportRoot.add(cloneForExport(child));
      }
    });
    const exporter = new GLTFExporter();
    const options = { binary: true, embedImages: true };
    exporter.parse(
      exportRoot,
      (result) => {
        if (result instanceof ArrayBuffer) {
          const blob = new Blob([result], { type: "model/gltf-binary" });

          saveBlob(blob, "scene.glb").catch((e) =>
            console.error("Save failed", e)
          );
        } else {
          console.error("GLB export failed: unexpected result", result);
        }
      },
      (error) => {
        console.error("An error occurred during export", error);
      },
      options
    );
  };
  return null;
}

function Kick() {
  // Khi chuyển chế độ vẽ khung hình, buộc vẽ lại một lần
  const invalidate = useThree((state) => state.invalidate);
  const thirdMode = useCarStore((state) => state.thirdMode);
  useEffect(() => {
    invalidate();
  }, [thirdMode, invalidate]);
  return null;
}

export function Space({ active = true }: { active?: boolean }) {
  const areas = useAreaStore((state) => state.areas);
  const [realCenter, setRealCenter] = useState<any>();
  const center = useAreaStore((state) => state.center);
  const overrides = useAreaStore((state) => state.heightOverrides);
  const setHeight = useAreaStore((state) => state.setHeight);
  const thirdMode = useCarStore((state) => state.thirdMode);
  const refLat = (center[1].lat + center[0].lat) / 2;
  const refLng = (center[1].lng + center[0].lng) / 2;
  const [terrain, setTerrain] = useState<TerrainSampler | null>(null);
  const [terrainStatus, setTerrainStatus] = useState<"idle" | "loading" | "error">(
    "idle"
  );

  // Tải độ cao địa hình khi vào bước xem 3D
  useEffect(() => {
    if (!active) return;
    let cancelled = false;
    setTerrain(null);
    setTerrainStatus("loading");
    loadTerrain({
      south: Math.min(center[0].lat, center[1].lat),
      north: Math.max(center[0].lat, center[1].lat),
      west: Math.min(center[0].lng, center[1].lng),
      east: Math.max(center[0].lng, center[1].lng),
    })
      .then((t) => {
        if (cancelled) return;
        setTerrain(t);
        setTerrainStatus("idle");
      })
      .catch((e) => {
        console.error("Terrain", e);
        if (!cancelled) setTerrainStatus("error");
      });
    return () => {
      cancelled = true;
    };
  }, [active, center]);

  const [texSource, setTexSource] = useState<"elevation" | SatSource>("esri");
  const [satellite, setSatellite] = useState<HTMLCanvasElement | null>(null);
  const [satStatus, setSatStatus] = useState<"idle" | "loading" | "error">("idle");

  // Tải ảnh vệ tinh làm texture mặt đất
  useEffect(() => {
    if (!active || texSource === "elevation") {
      setSatellite(null);
      setSatStatus("idle");
      return;
    }
    let cancelled = false;
    setSatStatus("loading");
    loadSatellite(
      {
        south: Math.min(center[0].lat, center[1].lat),
        north: Math.max(center[0].lat, center[1].lat),
        west: Math.min(center[0].lng, center[1].lng),
        east: Math.max(center[0].lng, center[1].lng),
      },
      texSource
    )
      .then((c) => {
        if (cancelled) return;
        setSatellite(c);
        setSatStatus("idle");
      })
      .catch((e) => {
        console.error("Satellite", e);
        if (!cancelled) {
          setSatellite(null);
          setSatStatus("error");
        }
      });
    return () => {
      cancelled = true;
    };
  }, [active, center, texSource]);

  // Độ cao tại tọa độ trong cảnh (x, z) — dùng cho xe
  const groundAt = useCallback(
    (x: number, z: number) => {
      if (!terrain) return 0;
      const lat = refLat - z / scale;
      const lng = refLng + x / (scale * Math.cos((refLat * Math.PI) / 180));
      return terrain.heightAt(lat, lng) * ELEV_SCALE;
    },
    [terrain, refLat, refLng]
  );

  // Shape chỉ tính lại khi đổi vùng; chỉnh chiều cao không dựng lại các tòa khác
  const buildingsData = useMemo(() => {
    const project = (lat: number, lng: number) => {
      const x = (lng - refLng) * scale * Math.cos((refLat * Math.PI) / 180);
      const y = (lat - refLat) * scale;
      return new THREE.Vector2(x, y);
    };
    const result: Array<{
      id: number | string;
      shape: THREE.Shape;
      baseHeight: number;
      baseY: number;
      color: string;
      tags: any;
    }> = [];
    areas.forEach((bld: any, index: number) => {
      if (!bld.geometry || bld.geometry.length < 3) return;
      const shapePoints = bld.geometry.map((pt: any) => project(pt.lat, pt.lng));
      if (!shapePoints[0].equals(shapePoints[shapePoints.length - 1]))
        shapePoints.push(shapePoints[0]);
      const shape = new THREE.Shape(shapePoints);
      let heightValue = parseFloat(bld.tags?.height || "");
      const heightLevels = parseFloat(bld.tags?.["building:levels"] || "");
      // Ưu tiên: height > số tầng × 3m > mặc định 10m
      if (isNaN(heightValue)) {
        heightValue = !isNaN(heightLevels) ? heightLevels * 3 : 10;
      }
      // Chân tòa nhà đặt ở điểm thấp nhất của móng để không bị lơ lửng trên dốc
      let baseY = 0;
      if (terrain) {
        baseY = Infinity;
        for (const pt of bld.geometry) {
          baseY = Math.min(baseY, terrain.heightAt(pt.lat, pt.lng));
        }
        baseY = (isFinite(baseY) ? baseY : 0) * ELEV_SCALE;
      }
      result.push({
        id: bld.id ?? `i${index}`,
        shape,
        baseHeight: heightValue,
        baseY,
        color: buildingColor(bld.id ?? `i${index}`, bld.tags),
        tags: bld.tags || {},
      });
    });
    return result;
  }, [areas, refLat, refLng, terrain]);

  useEffect(() => {
    setRealCenter(center);
  }, [areas]);

  // Chỉ dựng cảnh 3D khi đang ở bước xem 3D để tiết kiệm pin và bộ nhớ
  if (!active) return null;

  return (
    <>
    <div
      style={{
        position: "fixed",
        top: "calc(env(safe-area-inset-top, 0px) + 4.5rem)",
        left: "12px",
        zIndex: 10,
        display: "flex",
        gap: "4px",
        padding: "4px",
        borderRadius: "12px",
        background: "rgba(255,255,255,0.85)",
        boxShadow: "0 2px 10px rgba(0,0,0,0.12)",
        fontFamily: "system-ui, -apple-system, sans-serif",
        fontSize: "12px",
      }}
    >
      {(
        [
          ["esri", "Vệ tinh Esri"],
          ["sentinel", "Sentinel-2"],
          ["elevation", "Độ cao"],
        ] as const
      ).map(([key, label]) => (
        <button
          key={key}
          onClick={() => setTexSource(key)}
          style={{
            border: "none",
            borderRadius: "8px",
            padding: "6px 8px",
            fontSize: "12px",
            fontWeight: 600,
            cursor: "pointer",
            color: texSource === key ? "#ffffff" : "#0b1f2e",
            background: texSource === key ? "#0e9aa7" : "transparent",
          }}
        >
          {label}
        </button>
      ))}
    </div>
    {(terrainStatus !== "idle" || satStatus !== "idle") && (
      <div
        style={{
          position: "fixed",
          top: "calc(env(safe-area-inset-top, 0px) + 7.8rem)",
          left: "12px",
          zIndex: 10,
          pointerEvents: "none",
          padding: "6px 12px",
          borderRadius: "999px",
          fontSize: "13px",
          fontFamily: "system-ui, -apple-system, sans-serif",
          color:
            terrainStatus === "error" || satStatus === "error" ? "#b42318" : "#0b1f2e",
          background: "rgba(255,255,255,0.85)",
          boxShadow: "0 2px 10px rgba(0,0,0,0.12)",
        }}
      >
        {terrainStatus === "error"
          ? "Không tải được địa hình, hiển thị mặt phẳng"
          : satStatus === "error"
          ? "Không tải được ảnh vệ tinh, dùng màu theo độ cao"
          : terrainStatus === "loading"
          ? "Đang tải địa hình…"
          : "Đang tải ảnh vệ tinh…"}
      </div>
    )}
    {satellite && texSource !== "elevation" && (
      <div
        style={{
          position: "fixed",
          left: "8px",
          bottom: "calc(env(safe-area-inset-bottom, 0px) + 4px)",
          zIndex: 10,
          pointerEvents: "none",
          fontSize: "10px",
          color: "#ffffff",
          textShadow: "0 0 3px rgba(0,0,0,0.8)",
          fontFamily: "system-ui, -apple-system, sans-serif",
        }}
      >
        {satCredit(texSource)}
      </div>
    )}
    <Canvas
      camera={{ fov: 90, near: 0.1, far: 7000 }}
      dpr={[1, 2]}
      frameloop={thirdMode ? "always" : "demand"}
    >
      <Kick />
      <ambientLight intensity={Math.PI / 2} />
      <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} decay={0} intensity={Math.PI} />
      {buildingsData.map((item) => (
        <Building
          key={item.id}
          id={item.id}
          shape={item.shape}
          depth={overrides[String(item.id)] ?? item.baseHeight}
          y={item.baseY}
          color={item.color}
          isEdited={String(item.id) in overrides}
          tags={item.tags}
          onHeightChange={setHeight}
        />
      ))}

      {terrain && <Terrain center={center} terrain={terrain} satellite={satellite} />}
      <Roads area={realCenter} terrain={terrain} />
      <pointLight position={[-10, -10, -10]} decay={0} intensity={Math.PI} />
      <Car groundAt={groundAt} />
      <Export />
      <Sky distance={450000} sunPosition={[0, 1, 0]} inclination={0} azimuth={0.25} />
      <Environment preset="city" />
    </Canvas>
    </>
  );
}
