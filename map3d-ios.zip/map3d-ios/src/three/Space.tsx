import { memo, useEffect, useMemo, useState } from "react";
import type { CSSProperties } from "react";
import { Canvas, extend, ReactThreeFiber, useThree } from "@react-three/fiber";
import { useAreaStore } from "@/state/areaStore";
import { Html, Sky, Environment, Line } from "@react-three/drei";
import * as THREE from "three";
import { useActionStore } from "@/state/exportStore";
import {
  GLTFExporter,
  USDZExporter,
  OBJExporter,
  STLExporter,
} from "three/examples/jsm/Addons.js";
import Car from "./Car";
import { useCarStore } from "@/state/carStore";
import { overpass } from "@/utils/overpass";
import { saveBlob } from "@/utils/saveFile";

const scale = 51000;

const Building = memo(function Building({
  id,
  shape,
  depth,
  isEdited,
  tags,
  onHeightChange,
}: {
  id: number | string;
  shape: THREE.Shape;
  depth: number;
  isEdited: boolean;
  tags: any;
  onHeightChange: (id: number | string, height: number | null) => void;
}) {
  const extrudeSettings = useMemo(
    () => ({ steps: 1, depth, bevelEnabled: false }),
    [depth]
  );
  const [hovered, setHovered] = useState(false);
  const [clicked, setClicked] = useState(false);
  const [hoverPos, setHoverPos] = useState<THREE.Vector3 | null>(null);
  const [showTranslations, setShowTranslations] = useState(false);
  const [showAdditionalInfo, setShowAdditionalInfo] = useState(false);
  return (
    <mesh
      onPointerOver={(e) => {
        setHovered(true);
        e.stopPropagation();
      }}
      onPointerOut={(e) => {
        setHovered(false);
        e.stopPropagation();
      }}
      onPointerMove={(e) => {
        setHoverPos(e.point.clone());
        e.stopPropagation();
      }}
      onClick={(e) => {
        setClicked(!clicked);
        e.stopPropagation();
      }}
      rotation={[-Math.PI / 2, 0, 0]}
      userData={{ exportToGLB: true }}
    >
      <extrudeGeometry args={[shape, extrudeSettings]} />
      <meshStandardMaterial color={hovered || clicked ? "#007bff" : "#9da0a3"} />
      {(hovered || clicked) && hoverPos && (
        <Html position={[hoverPos.x, hoverPos.y + extrudeSettings.depth + 0.5, hoverPos.z]} center>
          <div
            role="dialog"
            aria-label={tags.name || "Thông tin tòa nhà"}
            style={{
              color: "#000000",
              backgroundColor: "#ffffff96",
              backdropFilter: "blur(8px)",
              border: "none",
              padding: "14px",
              borderRadius: "10px",
              fontFamily: "system-ui, -apple-system, sans-serif",
              fontSize: "13px",
              width: "200px",
              boxShadow: "0 2px 14px rgba(0, 0, 0, 0.16)",
              transition: "all 0.2s ease-in-out",
            }}
          >
            <div
              style={{
                fontWeight: "600",
                fontSize: "15px",
                borderBottom: tags.name ? "1px solid rgba(0, 0, 0, 0.08)" : "none",
                paddingBottom: tags.name ? "6px" : "0",
                marginBottom: tags.name ? "8px" : "4px",
              }}
            >
              {tags.name || "Thông tin tòa nhà"}
            </div>
            {clicked && (
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                  margin: "6px 0 8px",
                }}
              >
                <span style={{ fontWeight: 500, color: "#5f6368", flex: 1 }}>
                  Cao (m)
                </span>
                <button
                  style={editBtn}
                  onClick={() => onHeightChange(id, Math.max(1, depth - 1))}
                >
                  −
                </button>
                <input
                  type="number"
                  inputMode="decimal"
                  value={Math.round(depth * 10) / 10}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value);
                    if (!isNaN(v) && v > 0) onHeightChange(id, v);
                  }}
                  style={{
                    width: "52px",
                    textAlign: "center",
                    border: "1px solid rgba(0,0,0,0.15)",
                    borderRadius: "8px",
                    padding: "6px 2px",
                    fontSize: "14px",
                    userSelect: "text",
                    WebkitUserSelect: "text",
                  }}
                />
                <button
                  style={editBtn}
                  onClick={() => onHeightChange(id, depth + 1)}
                >
                  +
                </button>
              </div>
            )}
            {clicked && isEdited && (
              <button
                style={{ ...editBtn, width: "100%", marginBottom: "6px" }}
                onClick={() => onHeightChange(id, null)}
              >
                Đặt lại chiều cao gốc
              </button>
            )}
            {["building", "height", "building:levels", "amenity", "denomination"].map(
              (key) =>
                tags[key] &&
                (key !== "building" || tags[key] !== "yes") && (
                  <div
                    key={key}
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      margin: "4px 0",
                    }}
                  >
                    <span style={{ fontWeight: "500", color: "#5f6368" }}>
                      {key === "building"
                        ? "Loại"
                        : key === "height"
                        ? "Chiều cao"
                        : key === "building:levels"
                        ? "Số tầng"
                        : key === "amenity"
                        ? "Tiện ích"
                        : key === "denomination"
                        ? "Giáo phái"
                        : key.replace(/_/g, " ")}
                      :
                    </span>
                    <span style={{ textTransform: "capitalize" }}>
                      {key === "height" ? `${tags[key]} m` : tags[key]}
                    </span>
                  </div>
                )
            )}
            {[
              "addr:street",
              "addr:housenumber",
              "addr:district",
              "addr:city",
              "addr:postcode",
            ].some((key) => tags[key]) && (
              <div
                style={{
                  margin: "10px 0 8px",
                  borderTop: "1px solid rgba(0, 0, 0, 0.08)",
                  paddingTop: "8px",
                }}
              >
                <div style={{ fontWeight: "500", marginBottom: "4px", color: "#5f6368" }}>
                  Địa chỉ
                </div>
                <div style={{ marginLeft: "4px", fontSize: "12px", color: "#5f6368" }}>
                  {[
                    [tags["addr:street"], tags["addr:housenumber"]].filter(Boolean).join(" "),
                    tags["addr:district"],
                    tags["addr:city"],
                    tags["addr:postcode"],
                  ]
                    .filter(Boolean)
                    .join(", ")}
                </div>
              </div>
            )}
            {Object.entries(tags).filter(
              ([key]) =>
                ![
                  "building",
                  "name",
                  "height",
                  "building:levels",
                  "source",
                  "amenity",
                  "denomination",
                ].includes(key) &&
                !key.startsWith("addr:") &&
                !key.startsWith("name:") &&
                !key.startsWith("alt_name:")
            ).length > 0 && (
              <div
                style={{
                  margin: "10px 0 4px",
                  borderTop: "1px solid rgba(0, 0, 0, 0.08)",
                  paddingTop: "8px",
                }}
              >
                <div
                  style={{
                    fontWeight: "500",
                    marginBottom: "4px",
                    color: "#5f6368",
                    cursor: "pointer",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                  onClick={() => setShowAdditionalInfo(!showAdditionalInfo)}
                >
                  Thông tin thêm
                  <span>{showAdditionalInfo ? "▲" : "▼"}</span>
                </div>
                {showAdditionalInfo && (
                  <div>
                    {Object.entries(tags)
                      .filter(
                        ([key]) =>
                          ![
                            "building",
                            "name",
                            "height",
                            "building:levels",
                            "source",
                            "amenity",
                            "denomination",
                          ].includes(key) &&
                          !key.startsWith("addr:") &&
                          !key.startsWith("name:") &&
                          !key.startsWith("alt_name:")
                      )
                      .map(([key, value]) => {
                        if (
                          key === "description" ||
                          (typeof value === "string" && value.length > 80)
                        ) {
                          return (
                            <div key={key} style={{ margin: "8px 0" }}>
                              <div
                                style={{ fontWeight: "500", color: "#5f6368", marginBottom: "4px" }}
                              >
                                {key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, " ")}
                              </div>
                              <div
                                style={{
                                  textAlign: "left",
                                  fontSize: "12px",
                                  color: "#5f6368",
                                  fontWeight: "400",
                                  textWrap: "wrap",
                                  whiteSpace: "pre-wrap",
                                  lineHeight: "1.4",
                                  backgroundColor: "rgba(0,0,0,0.02)",
                                  padding: "6px 8px",
                                  borderRadius: "4px",
                                }}
                              >
                                {String(value)}
                              </div>
                            </div>
                          );
                        }
                        return (
                          <div
                            key={key}
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              margin: "4px 0",
                            }}
                          >
                            <span
                              style={{
                                fontWeight: "700",
                                color: "#5f6368",
                                textAlign: "left",
                              }}
                            >
                              {key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, " ")}:
                            </span>
                            <span
                              style={{
                                textTransform: "capitalize",
                                fontWeight: "400",
                                textAlign: "right",
                              }}
                            >
                              {String(value)}
                            </span>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>
            )}
            {Object.entries(tags).filter(([key]) => key.startsWith("name:")).length > 0 && (
              <div
                style={{
                  margin: "10px 0 4px",
                  borderTop: "1px solid rgba(0, 0, 0, 0.08)",
                  paddingTop: "8px",
                  textAlign: "right",
                }}
              >
                <div
                  style={{
                    fontWeight: "500",
                    marginBottom: "4px",
                    color: "#5f6368",
                    cursor: "pointer",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                  onClick={() => setShowTranslations(!showTranslations)}
                >
                  Name Translations
                  <span>{showTranslations ? "▲" : "▼"}</span>
                </div>
                {showTranslations && (
                  <div>
                    {Object.entries(tags)
                      .filter(([key]) => key.startsWith("name:"))
                      .map(([key, value]) => (
                        <div
                          key={key}
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            margin: "4px 0",
                          }}
                        >
                          <span style={{ fontWeight: "500", color: "#5f6368" }}>
                            {key.replace("name:", "").toUpperCase()}:
                          </span>
                          <span style={{ textTransform: "capitalize" }}>{String(value)}</span>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </Html>
      )}
    </mesh>
  );
});

const editBtn: CSSProperties = {
  border: "none",
  borderRadius: "8px",
  background: "#0b1f2e0d",
  padding: "6px 10px",
  fontSize: "14px",
  fontWeight: 600,
  cursor: "pointer",
};

function Roads({ area }: { area: any }) {
  const [roads, setRoads] = useState<any[]>([]);

  useEffect(() => {
    if (!area || area.length < 2) return;
    const south = area[1].lat;
    const west = area[1].lng;
    const north = area[0].lat;
    const east = area[0].lng;
    const query = `[out:json][timeout:25];(way["highway"](${south},${west},${north},${east}););out body geom;`;
    let cancelled = false;
    overpass(query)
      .then((data) => {
        if (!cancelled) setRoads(data.elements || []);
      })
      .catch((err) => console.error("Roads", err));
    return () => {
      cancelled = true;
    };
  }, [area]);

  if (!area || area.length < 2) return null;
  const refLat = (area[1].lat + area[0].lat) / 2;
  const refLng = (area[1].lng + area[0].lng) / 2;

  function project(lat: number, lng: number) {
    const x = (lng - refLng) * scale * Math.cos((refLat * Math.PI) / 180);
    const y = (lat - refLat) * scale;
    return new THREE.Vector2(x, y);
  }

  return (
    <>
      {roads.map((road, index) => {
        if (!road.geometry || road.geometry.length < 2) return null;

        const points = road.geometry.map((pt: any) => {
          const v = project(pt.lat, pt.lon);
          return new THREE.Vector3(v.x, 0.1, -v.y);
        });

        const lineGeometry: any = new THREE.BufferGeometry().setFromPoints(points);

        return (
          <Line
            key={road.id ?? index}
            points={points}
            color="#34f516"
            lineWidth={1}
            userData={{ exportToGLB: true }}
          ></Line>
        );
      })}
    </>
  );
}

export function Export() {
  const { scene } = useThree();
  const action = useActionStore((state) => state.action);

  const exportType = useActionStore((state) => state.exportType);

  const setAction = useActionStore((state) => state.setAction);

  useEffect(() => {
    if (action === true) {
      setAction(false);
      if (exportType === "usdz") {
        exportUSDZ();
      } else if (exportType === "obj" || exportType === "stl") {
        exportMesh(exportType);
      } else {
        exportGLB();
      }
    }
  }, [action, setAction, scene]);

  const exportMesh = async (type: "obj" | "stl") => {
    try {
      const root = new THREE.Group();
      scene.traverse((child) => {
        if (child.userData?.exportToGLB === true) {
          const c: any = child.clone(true);
          if (c.isMesh && c.material?.isMeshStandardMaterial) root.add(c);
        }
      });
      if (root.children.length === 0) {
        throw new Error("Không có mô hình để xuất");
      }
      root.updateMatrixWorld(true);
      if (type === "obj") {
        const text = new OBJExporter().parse(root);
        await saveBlob(new Blob([text], { type: "text/plain" }), "map3d.obj");
      } else {
        const view = new STLExporter().parse(root, { binary: true });
        await saveBlob(
          new Blob([view as any], { type: "model/stl" }),
          "map3d.stl"
        );
      }
    } catch (error) {
      console.error("Export failed", error);
      alert("Xuất file thất bại: " + (error as Error).message);
    }
  };

  const exportUSDZ = async () => {
    try {
      const root = new THREE.Group();
      scene.traverse((child) => {
        if (child.userData?.exportToGLB === true) {
          const c: any = child.clone(true);
          // USDZ chỉ hỗ trợ mesh với vật liệu Standard (bỏ đường kẻ/đường đi)
          if (c.isMesh && c.material?.isMeshStandardMaterial) {
            root.add(c);
          }
        }
      });
      if (root.children.length === 0) {
        throw new Error("Không có mô hình để xuất");
      }
      // Thu nhỏ về cỡ mặt bàn (~50 cm) để xem AR, đặt đáy chạm sàn
      const box = new THREE.Box3().setFromObject(root);
      const size = box.getSize(new THREE.Vector3());
      const maxDim = Math.max(size.x, size.y, size.z) || 1;
      const k = 0.5 / maxDim;
      const wrapper = new THREE.Group();
      wrapper.add(root);
      root.position.set(
        -(box.min.x + box.max.x) / 2,
        -box.min.y,
        -(box.min.z + box.max.z) / 2
      );
      wrapper.scale.setScalar(k);
      wrapper.updateMatrixWorld(true);

      const exporter: any = new USDZExporter();
      const data: Uint8Array = await (exporter.parseAsync
        ? exporter.parseAsync(wrapper)
        : exporter.parse(wrapper));
      const blob = new Blob([data], { type: "model/vnd.usdz+zip" });
      await saveBlob(blob, "map3d.usdz");
    } catch (error) {
      console.error("USDZ export failed", error);
      alert("Xuất USDZ thất bại: " + (error as Error).message);
    }
  };

  const exportGLB = () => {
    const exportRoot = new THREE.Group();
    scene.traverse((child) => {
      if (child.userData?.exportToGLB === true) {
        exportRoot.add(child.clone(true));
      }
    });
    const exporter = new GLTFExporter();
    const options = { binary: true, embedImages: true };
    exporter.parse(
      exportRoot,
      (result) => {
        if (result instanceof ArrayBuffer) {
          const blob = new Blob([result], { type: "model/gltf-binary" });

          saveBlob(blob, "scene.glb").catch((e) =>
            console.error("Save failed", e)
          );
        } else {
          console.error("GLB export failed: unexpected result", result);
        }
      },
      (error) => {
        console.error("An error occurred during export", error);
      },
      options
    );
  };
  return null;
}

function Kick() {
  // Khi chuyển chế độ vẽ khung hình, buộc vẽ lại một lần
  const invalidate = useThree((state) => state.invalidate);
  const thirdMode = useCarStore((state) => state.thirdMode);
  useEffect(() => {
    invalidate();
  }, [thirdMode, invalidate]);
  return null;
}

export function Space({ active = true }: { active?: boolean }) {
  const areas = useAreaStore((state) => state.areas);
  const [realCenter, setRealCenter] = useState<any>();
  const center = useAreaStore((state) => state.center);
  const overrides = useAreaStore((state) => state.heightOverrides);
  const setHeight = useAreaStore((state) => state.setHeight);
  const thirdMode = useCarStore((state) => state.thirdMode);
  const refLat = (center[1].lat + center[0].lat) / 2;
  const refLng = (center[1].lng + center[0].lng) / 2;

  // Shape chỉ tính lại khi đổi vùng; chỉnh chiều cao không dựng lại các tòa khác
  const buildingsData = useMemo(() => {
    const project = (lat: number, lng: number) => {
      const x = (lng - refLng) * scale * Math.cos((refLat * Math.PI) / 180);
      const y = (lat - refLat) * scale;
      return new THREE.Vector2(x, y);
    };
    const result: Array<{
      id: number | string;
      shape: THREE.Shape;
      baseHeight: number;
      tags: any;
    }> = [];
    areas.forEach((bld: any, index: number) => {
      if (!bld.geometry || bld.geometry.length < 3) return;
      const shapePoints = bld.geometry.map((pt: any) => project(pt.lat, pt.lng));
      if (!shapePoints[0].equals(shapePoints[shapePoints.length - 1]))
        shapePoints.push(shapePoints[0]);
      const shape = new THREE.Shape(shapePoints);
      let heightValue = parseFloat(bld.tags?.height || "");
      const heightLevels = parseFloat(bld.tags?.["building:levels"] || "");
      // Ưu tiên: height > số tầng × 3m > mặc định 10m
      if (isNaN(heightValue)) {
        heightValue = !isNaN(heightLevels) ? heightLevels * 3 : 10;
      }
      result.push({
        id: bld.id ?? `i${index}`,
        shape,
        baseHeight: heightValue,
        tags: bld.tags || {},
      });
    });
    return result;
  }, [areas, refLat, refLng]);

  useEffect(() => {
    setRealCenter(center);
  }, [areas]);

  // Chỉ dựng cảnh 3D khi đang ở bước xem 3D để tiết kiệm pin và bộ nhớ
  if (!active) return null;

  return (
    <Canvas
      camera={{ fov: 90, near: 0.1, far: 7000 }}
      dpr={[1, 2]}
      frameloop={thirdMode ? "always" : "demand"}
    >
      <Kick />
      <ambientLight intensity={Math.PI / 2} />
      <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} decay={0} intensity={Math.PI} />
      {buildingsData.map((item) => (
        <Building
          key={item.id}
          id={item.id}
          shape={item.shape}
          depth={overrides[String(item.id)] ?? item.baseHeight}
          isEdited={String(item.id) in overrides}
          tags={item.tags}
          onHeightChange={setHeight}
        />
      ))}

      <Roads area={realCenter} />
      <pointLight position={[-10, -10, -10]} decay={0} intensity={Math.PI} />
      <Car />
      <Export />
      <Sky distance={450000} sunPosition={[0, 1, 0]} inclination={0} azimuth={0.25} />
      <Environment preset="city" />
    </Canvas>
  );
}
