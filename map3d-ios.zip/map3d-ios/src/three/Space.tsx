import { memo, useCallback, useEffect, useMemo, useState } from "react";
import type { CSSProperties } from "react";
import { Canvas, extend, ReactThreeFiber, useThree } from "@react-three/fiber";
import { useAreaStore } from "@/state/areaStore";
import { Html, Sky, Environment, Line } from "@react-three/drei";
import * as THREE from "three";
import { useActionStore } from "@/state/exportStore";
import {
  GLTFExporter,
  USDZExporter,
  OBJExporter,
  STLExporter,
} from "three/examples/jsm/Addons.js";
import Car from "./Car";
import { useCarStore } from "@/state/carStore";
import { overpass } from "@/utils/overpass";
import { saveBlob } from "@/utils/saveFile";
import { loadTerrain } from "@/utils/terrain";
import type { TerrainSampler } from "@/utils/terrain";

const scale = 51000;
/** Độ cao địa hình theo mét, nhân hệ số này (cùng quy ước với chiều cao tòa nhà) */
const ELEV_SCALE = 1;

const Building = memo(function Building({
  id,
  shape,
  depth,
  y,
  isEdited,
  tags,
  onHeightChange,
}: {
  id: number | string;
  shape: THREE.Shape;
  depth: number;
  y: number;
  isEdited: boolean;
  tags: any;
  onHeightChange: (id: number | string, height: number | null) => void;
}) {
  const extrudeSettings = useMemo(
    () => ({ steps: 1, depth, bevelEnabled: false }),
    [depth]
  );
  const [hovered, setHovered] = useState(false);
  const [clicked, setClicked] = useState(false);
  const [hoverPos, setHoverPos] = useState<THREE.Vector3 | null>(null);
  const [showTranslations, setShowTranslations] = useState(false);
  const [showAdditionalInfo, setShowAdditionalInfo] = useState(false);
  return (
    <mesh
      onPointerOver={(e) => {
        setHovered(true);
        e.stopPropagation();
      }}
      onPointerOut={(e) => {
        setHovered(false);
        e.stopPropagation();
      }}
      onPointerMove={(e) => {
        setHoverPos(e.point.clone());
        e.stopPropagation();
      }}
      onClick={(e) => {
        setClicked(!clicked);
        e.stopPropagation();
      }}
      position={[0, y, 0]}
      rotation={[-Math.PI / 2, 0, 0]}
      userData={{ exportToGLB: true }}
    >
      <extrudeGeometry args={[shape, extrudeSettings]} />
      <meshStandardMaterial color={hovered || clicked ? "#007bff" : "#9da0a3"} />
      {(hovered || clicked) && hoverPos && (
        <Html position={[hoverPos.x, hoverPos.y + extrudeSettings.depth + 0.5, hoverPos.z]} center>
          <div
            role="dialog"
            aria-label={tags.name || "Thông tin tòa nhà"}
            style={{
              color: "#000000",
              backgroundColor: "#ffffff96",
              backdropFilter: "blur(8px)",
              border: "none",
              padding: "14px",
              borderRadius: "10px",
              fontFamily: "system-ui, -apple-system, sans-serif",
              fontSize: "13px",
              width: "200px",
              boxShadow: "0 2px 14px rgba(0, 0, 0, 0.16)",
              transition: "all 0.2s ease-in-out",
            }}
          >
            <div
              style={{
                fontWeight: "600",
                fontSize: "15px",
                borderBottom: tags.name ? "1px solid rgba(0, 0, 0, 0.08)" : "none",
                paddingBottom: tags.name ? "6px" : "0",
                marginBottom: tags.name ? "8px" : "4px",
              }}
            >
              {tags.name || "Thông tin tòa nhà"}
            </div>
            {clicked && (
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                  margin: "6px 0 8px",
                }}
              >
                <span style={{ fontWeight: 500, color: "#5f6368", flex: 1 }}>
                  Cao (m)
                </span>
                <button
                  style={editBtn}
                  onClick={() => onHeightChange(id, Math.max(1, depth - 1))}
                >
                  −
                </button>
                <input
                  type="number"
                  inputMode="decimal"
                  value={Math.round(depth * 10) / 10}
                  onChange={(e) => {
                    const v = parseFloat(e.target.value);
                    if (!isNaN(v) && v > 0) onHeightChange(id, v);
                  }}
                  style={{
                    width: "52px",
                    textAlign: "center",
                    border: "1px solid rgba(0,0,0,0.15)",
                    borderRadius: "8px",
                    padding: "6px 2px",
                    fontSize: "14px",
                    userSelect: "text",
                    WebkitUserSelect: "text",
                  }}
                />
                <button
                  style={editBtn}
                  onClick={() => onHeightChange(id, depth + 1)}
                >
                  +
                </button>
              </div>
            )}
            {clicked && isEdited && (
              <button
                style={{ ...editBtn, width: "100%", marginBottom: "6px" }}
                onClick={() => onHeightChange(id, null)}
              >
                Đặt lại chiều cao gốc
              </button>
            )}
            {["building", "height", "building:levels", "amenity", "denomination"].map(
              (key) =>
                tags[key] &&
                (key !== "building" || tags[key] !== "yes") && (
                  <div
                    key={key}
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      margin: "4px 0",
                    }}
                  >
                    <span style={{ fontWeight: "500", color: "#5f6368" }}>
                      {key === "building"
                        ? "Loại"
                        : key === "height"
                        ? "Chiều cao"
                        : key === "building:levels"
                        ? "Số tầng"
                        : key === "amenity"
                        ? "Tiện ích"
                        : key === "denomination"
                        ? "Giáo phái"
                        : key.replace(/_/g, " ")}
                      :
                    </span>
                    <span style={{ textTransform: "capitalize" }}>
                      {key === "height" ? `${tags[key]} m` : tags[key]}
                    </span>
                  </div>
                )
            )}
            {[
              "addr:street",
              "addr:housenumber",
              "addr:district",
              "addr:city",
              "addr:postcode",
            ].some((key) => tags[key]) && (
              <div
                style={{
                  margin: "10px 0 8px",
                  borderTop: "1px solid rgba(0, 0, 0, 0.08)",
                  paddingTop: "8px",
                }}
              >
                <div style={{ fontWeight: "500", marginBottom: "4px", color: "#5f6368" }}>
                  Địa chỉ
                </div>
                <div style={{ marginLeft: "4px", fontSize: "12px", color: "#5f6368" }}>
                  {[
                    [tags["addr:street"], tags["addr:housenumber"]].filter(Boolean).join(" "),
                    tags["addr:district"],
                    tags["addr:city"],
                    tags["addr:postcode"],
                  ]
                    .filter(Boolean)
                    .join(", ")}
                </div>
              </div>
            )}
            {Object.entries(tags).filter(
              ([key]) =>
                ![
                  "building",
                  "name",
                  "height",
                  "building:levels",
                  "source",
                  "amenity",
                  "denomination",
                ].includes(key) &&
                !key.startsWith("addr:") &&
                !key.startsWith("name:") &&
                !key.startsWith("alt_name:")
            ).length > 0 && (
              <div
                style={{
                  margin: "10px 0 4px",
                  borderTop: "1px solid rgba(0, 0, 0, 0.08)",
                  paddingTop: "8px",
                }}
              >
                <div
                  style={{
                    fontWeight: "500",
                    marginBottom: "4px",
                    color: "#5f6368",
                    cursor: "pointer",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                  onClick={() => setShowAdditionalInfo(!showAdditionalInfo)}
                >
                  Thông tin thêm
                  <span>{showAdditionalInfo ? "▲" : "▼"}</span>
                </div>
                {showAdditionalInfo && (
                  <div>
                    {Object.entries(tags)
                      .filter(
                        ([key]) =>
                          ![
                            "building",
                            "name",
                            "height",
                            "building:levels",
                            "source",
                            "amenity",
                            "denomination",
                          ].includes(key) &&
                          !key.startsWith("addr:") &&
                          !key.startsWith("name:") &&
                          !key.startsWith("alt_name:")
                      )
                      .map(([key, value]) => {
                        if (
                          key === "description" ||
                          (typeof value === "string" && value.length > 80)
                        ) {
                          return (
                            <div key={key} style={{ margin: "8px 0" }}>
                              <div
                                style={{ fontWeight: "500", color: "#5f6368", marginBottom: "4px" }}
                              >
                                {key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, " ")}
                              </div>
                              <div
                                style={{
                                  textAlign: "left",
                                  fontSize: "12px",
                                  color: "#5f6368",
                                  fontWeight: "400",
                                  textWrap: "wrap",
                                  whiteSpace: "pre-wrap",
                                  lineHeight: "1.4",
                                  backgroundColor: "rgba(0,0,0,0.02)",
                                  padding: "6px 8px",
                                  borderRadius: "4px",
                                }}
                              >
                                {String(value)}
                              </div>
                            </div>
                          );
                        }
                        return (
                          <div
                            key={key}
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              margin: "4px 0",
                            }}
                          >
                            <span
                              style={{
                                fontWeight: "700",
                                color: "#5f6368",
                                textAlign: "left",
                              }}
                            >
                              {key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, " ")}:
                            </span>
                            <span
                              style={{
                                textTransform: "capitalize",
                                fontWeight: "400",
                                textAlign: "right",
                              }}
                            >
                              {String(value)}
                            </span>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>
            )}
            {Object.entries(tags).filter(([key]) => key.startsWith("name:")).length > 0 && (
              <div
                style={{
                  margin: "10px 0 4px",
                  borderTop: "1px solid rgba(0, 0, 0, 0.08)",
                  paddingTop: "8px",
                  textAlign: "right",
                }}
              >
                <div
                  style={{
                    fontWeight: "500",
                    marginBottom: "4px",
                    color: "#5f6368",
                    cursor: "pointer",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                  onClick={() => setShowTranslations(!showTranslations)}
                >
                  Name Translations
                  <span>{showTranslations ? "▲" : "▼"}</span>
                </div>
                {showTranslations && (
                  <div>
                    {Object.entries(tags)
                      .filter(([key]) => key.startsWith("name:"))
                      .map(([key, value]) => (
                        <div
                          key={key}
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            margin: "4px 0",
                          }}
                        >
                          <span style={{ fontWeight: "500", color: "#5f6368" }}>
                            {key.replace("name:", "").toUpperCase()}:
                          </span>
                          <span style={{ textTransform: "capitalize" }}>{String(value)}</span>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </Html>
      )}
    </mesh>
  );
});

const editBtn: CSSProperties = {
  border: "none",
  borderRadius: "8px",
  background: "#0b1f2e0d",
  padding: "6px 10px",
  fontSize: "14px",
  fontWeight: 600,
  cursor: "pointer",
};

function Roads({
  area,
  terrain,
}: {
  area: any;
  terrain: TerrainSampler | null;
}) {
  const [roads, setRoads] = useState<any[]>([]);

  useEffect(() => {
    if (!area || area.length < 2) return;
    const south = area[1].lat;
    const west = area[1].lng;
    const north = area[0].lat;
    const east = area[0].lng;
    const query = `[out:json][timeout:25];(way["highway"](${south},${west},${north},${east}););out body geom;`;
    let cancelled = false;
    overpass(query)
      .then((data) => {
        if (!cancelled) setRoads(data.elements || []);
      })
      .catch((err) => console.error("Roads", err));
    return () => {
      cancelled = true;
    };
  }, [area]);

  if (!area || area.length < 2) return null;
  const refLat = (area[1].lat + area[0].lat) / 2;
  const refLng = (area[1].lng + area[0].lng) / 2;

  function project(lat: number, lng: number) {
    const x = (lng - refLng) * scale * Math.cos((refLat * Math.PI) / 180);
    const y = (lat - refLat) * scale;
    return new THREE.Vector2(x, y);
  }

  return (
    <>
      {roads.map((road, index) => {
        if (!road.geometry || road.geometry.length < 2) return null;

        const points = road.geometry.map((pt: any) => {
          const v = project(pt.lat, pt.lon);
          const h = terrain ? terrain.heightAt(pt.lat, pt.lon) * ELEV_SCALE : 0;
          return new THREE.Vector3(v.x, h + 0.35, -v.y);
        });

        return (
          <Line
            key={road.id ?? index}
            points={points}
            color="#34f516"
            lineWidth={1}
            userData={{ exportToGLB: true }}
          ></Line>
        );
      })}
    </>
  );
}

function Terrain({
  center,
  terrain,
}: {
  center: { lat: number; lng: number }[];
  terrain: TerrainSampler;
}) {
  const geometry = useMemo(() => {
    const south = Math.min(center[0].lat, center[1].lat);
    const north = Math.max(center[0].lat, center[1].lat);
    const west = Math.min(center[0].lng, center[1].lng);
    const east = Math.max(center[0].lng, center[1].lng);
    const refLat = (south + north) / 2;
    const refLng = (west + east) / 2;
    const kx = scale * Math.cos((refLat * Math.PI) / 180);
    const width = (east - west) * kx;
    const height = (north - south) * scale;
    const MAX = 128;
    const nx = Math.max(8, Math.round(width >= height ? MAX : (MAX * width) / height));
    const nz = Math.max(8, Math.round(height >= width ? MAX : (MAX * height) / width));

    const positions = new Float32Array((nx + 1) * (nz + 1) * 3);
    const colors = new Float32Array((nx + 1) * (nz + 1) * 3);
    const low = new THREE.Color("#b8c9a3");
    const mid = new THREE.Color("#c9b88f");
    const high = new THREE.Color("#f1f1ee");
    const tmp = new THREE.Color();
    const range = Math.max(terrain.range, 1);

    let v = 0;
    for (let i = 0; i <= nz; i++) {
      const lat = north - ((north - south) * i) / nz;
      for (let j = 0; j <= nx; j++) {
        const lng = west + ((east - west) * j) / nx;
        const h = terrain.heightAt(lat, lng);
        positions[v * 3] = (lng - refLng) * kx;
        positions[v * 3 + 1] = h * ELEV_SCALE;
        positions[v * 3 + 2] = -(lat - refLat) * scale;
        const t = Math.min(1, h / range);
        if (t < 0.5) tmp.copy(low).lerp(mid, t * 2);
        else tmp.copy(mid).lerp(high, (t - 0.5) * 2);
        colors[v * 3] = tmp.r;
        colors[v * 3 + 1] = tmp.g;
        colors[v * 3 + 2] = tmp.b;
        v++;
      }
    }

    const indices: number[] = [];
    for (let i = 0; i < nz; i++) {
      for (let j = 0; j < nx; j++) {
        const a = i * (nx + 1) + j;
        const b = a + 1;
        const c = a + (nx + 1);
        const d = c + 1;
        // Mặt hướng lên (+Y)
        indices.push(a, c, b, b, c, d);
      }
    }

    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    g.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    g.setIndex(indices);
    g.computeVertexNormals();
    return g;
  }, [center, terrain]);

  // Hạ nhẹ để chân tòa nhà và đường không bị lún/chớp mặt phẳng
  return (
    <mesh geometry={geometry} position={[0, -0.05, 0]} userData={{ exportToGLB: true }}>
      <meshStandardMaterial vertexColors />
    </mesh>
  );
}

export function Export() {
  const { scene } = useThree();
  const action = useActionStore((state) => state.action);

  const exportType = useActionStore((state) => state.exportType);

  const setAction = useActionStore((state) => state.setAction);

  useEffect(() => {
    if (action === true) {
      setAction(false);
      if (exportType === "usdz") {
        exportUSDZ();
      } else if (exportType === "obj" || exportType === "stl") {
        exportMesh(exportType);
      } else {
        exportGLB();
      }
    }
  }, [action, setAction, scene]);

  const exportMesh = async (type: "obj" | "stl") => {
    try {
      const root = new THREE.Group();
      scene.traverse((child) => {
        if (child.userData?.exportToGLB === true) {
          const c: any = child.clone(true);
          if (c.isMesh && c.material?.isMeshStandardMaterial) root.add(c);
        }
      });
      if (root.children.length === 0) {
        throw new Error("Không có mô hình để xuất");
      }
      root.updateMatrixWorld(true);
      if (type === "obj") {
        const text = new OBJExporter().parse(root);
        await saveBlob(new Blob([text], { type: "text/plain" }), "map3d.obj");
      } else {
        const view = new STLExporter().parse(root, { binary: true });
        await saveBlob(
          new Blob([view as any], { type: "model/stl" }),
          "map3d.stl"
        );
      }
    } catch (error) {
      console.error("Export failed", error);
      alert("Xuất file thất bại: " + (error as Error).message);
    }
  };

  const exportUSDZ = async () => {
    try {
      const root = new THREE.Group();
      scene.traverse((child) => {
        if (child.userData?.exportToGLB === true) {
          const c: any = child.clone(true);
          // USDZ chỉ hỗ trợ mesh với vật liệu Standard (bỏ đường kẻ/đường đi)
          if (c.isMesh && c.material?.isMeshStandardMaterial) {
            root.add(c);
          }
        }
      });
      if (root.children.length === 0) {
        throw new Error("Không có mô hình để xuất");
      }
      // Thu nhỏ về cỡ mặt bàn (~50 cm) để xem AR, đặt đáy chạm sàn
      const box = new THREE.Box3().setFromObject(root);
      const size = box.getSize(new THREE.Vector3());
      const maxDim = Math.max(size.x, size.y, size.z) || 1;
      const k = 0.5 / maxDim;
      const wrapper = new THREE.Group();
      wrapper.add(root);
      root.position.set(
        -(box.min.x + box.max.x) / 2,
        -box.min.y,
        -(box.min.z + box.max.z) / 2
      );
      wrapper.scale.setScalar(k);
      wrapper.updateMatrixWorld(true);

      const exporter: any = new USDZExporter();
      const data: Uint8Array = await (exporter.parseAsync
        ? exporter.parseAsync(wrapper)
        : exporter.parse(wrapper));
      const blob = new Blob([data], { type: "model/vnd.usdz+zip" });
      await saveBlob(blob, "map3d.usdz");
    } catch (error) {
      console.error("USDZ export failed", error);
      alert("Xuất USDZ thất bại: " + (error as Error).message);
    }
  };

  const exportGLB = () => {
    const exportRoot = new THREE.Group();
    scene.traverse((child) => {
      if (child.userData?.exportToGLB === true) {
        exportRoot.add(child.clone(true));
      }
    });
    const exporter = new GLTFExporter();
    const options = { binary: true, embedImages: true };
    exporter.parse(
      exportRoot,
      (result) => {
        if (result instanceof ArrayBuffer) {
          const blob = new Blob([result], { type: "model/gltf-binary" });

          saveBlob(blob, "scene.glb").catch((e) =>
            console.error("Save failed", e)
          );
        } else {
          console.error("GLB export failed: unexpected result", result);
        }
      },
      (error) => {
        console.error("An error occurred during export", error);
      },
      options
    );
  };
  return null;
}

function Kick() {
  // Khi chuyển chế độ vẽ khung hình, buộc vẽ lại một lần
  const invalidate = useThree((state) => state.invalidate);
  const thirdMode = useCarStore((state) => state.thirdMode);
  useEffect(() => {
    invalidate();
  }, [thirdMode, invalidate]);
  return null;
}

export function Space({ active = true }: { active?: boolean }) {
  const areas = useAreaStore((state) => state.areas);
  const [realCenter, setRealCenter] = useState<any>();
  const center = useAreaStore((state) => state.center);
  const overrides = useAreaStore((state) => state.heightOverrides);
  const setHeight = useAreaStore((state) => state.setHeight);
  const thirdMode = useCarStore((state) => state.thirdMode);
  const refLat = (center[1].lat + center[0].lat) / 2;
  const refLng = (center[1].lng + center[0].lng) / 2;
  const [terrain, setTerrain] = useState<TerrainSampler | null>(null);
  const [terrainStatus, setTerrainStatus] = useState<"idle" | "loading" | "error">(
    "idle"
  );

  // Tải độ cao địa hình khi vào bước xem 3D
  useEffect(() => {
    if (!active) return;
    let cancelled = false;
    setTerrain(null);
    setTerrainStatus("loading");
    loadTerrain({
      south: Math.min(center[0].lat, center[1].lat),
      north: Math.max(center[0].lat, center[1].lat),
      west: Math.min(center[0].lng, center[1].lng),
      east: Math.max(center[0].lng, center[1].lng),
    })
      .then((t) => {
        if (cancelled) return;
        setTerrain(t);
        setTerrainStatus("idle");
      })
      .catch((e) => {
        console.error("Terrain", e);
        if (!cancelled) setTerrainStatus("error");
      });
    return () => {
      cancelled = true;
    };
  }, [active, center]);

  // Độ cao tại tọa độ trong cảnh (x, z) — dùng cho xe
  const groundAt = useCallback(
    (x: number, z: number) => {
      if (!terrain) return 0;
      const lat = refLat - z / scale;
      const lng = refLng + x / (scale * Math.cos((refLat * Math.PI) / 180));
      return terrain.heightAt(lat, lng) * ELEV_SCALE;
    },
    [terrain, refLat, refLng]
  );

  // Shape chỉ tính lại khi đổi vùng; chỉnh chiều cao không dựng lại các tòa khác
  const buildingsData = useMemo(() => {
    const project = (lat: number, lng: number) => {
      const x = (lng - refLng) * scale * Math.cos((refLat * Math.PI) / 180);
      const y = (lat - refLat) * scale;
      return new THREE.Vector2(x, y);
    };
    const result: Array<{
      id: number | string;
      shape: THREE.Shape;
      baseHeight: number;
      baseY: number;
      tags: any;
    }> = [];
    areas.forEach((bld: any, index: number) => {
      if (!bld.geometry || bld.geometry.length < 3) return;
      const shapePoints = bld.geometry.map((pt: any) => project(pt.lat, pt.lng));
      if (!shapePoints[0].equals(shapePoints[shapePoints.length - 1]))
        shapePoints.push(shapePoints[0]);
      const shape = new THREE.Shape(shapePoints);
      let heightValue = parseFloat(bld.tags?.height || "");
      const heightLevels = parseFloat(bld.tags?.["building:levels"] || "");
      // Ưu tiên: height > số tầng × 3m > mặc định 10m
      if (isNaN(heightValue)) {
        heightValue = !isNaN(heightLevels) ? heightLevels * 3 : 10;
      }
      // Chân tòa nhà đặt ở điểm thấp nhất của móng để không bị lơ lửng trên dốc
      let baseY = 0;
      if (terrain) {
        baseY = Infinity;
        for (const pt of bld.geometry) {
          baseY = Math.min(baseY, terrain.heightAt(pt.lat, pt.lng));
        }
        baseY = (isFinite(baseY) ? baseY : 0) * ELEV_SCALE;
      }
      result.push({
        id: bld.id ?? `i${index}`,
        shape,
        baseHeight: heightValue,
        baseY,
        tags: bld.tags || {},
      });
    });
    return result;
  }, [areas, refLat, refLng, terrain]);

  useEffect(() => {
    setRealCenter(center);
  }, [areas]);

  // Chỉ dựng cảnh 3D khi đang ở bước xem 3D để tiết kiệm pin và bộ nhớ
  if (!active) return null;

  return (
    <>
    {terrainStatus !== "idle" && (
      <div
        style={{
          position: "fixed",
          top: "calc(env(safe-area-inset-top, 0px) + 4.5rem)",
          left: "50%",
          transform: "translateX(-50%)",
          zIndex: 10,
          pointerEvents: "none",
          padding: "6px 12px",
          borderRadius: "999px",
          fontSize: "13px",
          fontFamily: "system-ui, -apple-system, sans-serif",
          color: terrainStatus === "error" ? "#b42318" : "#0b1f2e",
          background: "rgba(255,255,255,0.85)",
          boxShadow: "0 2px 10px rgba(0,0,0,0.12)",
        }}
      >
        {terrainStatus === "loading"
          ? "Đang tải địa hình…"
          : "Không tải được địa hình, hiển thị mặt phẳng"}
      </div>
    )}
    <Canvas
      camera={{ fov: 90, near: 0.1, far: 7000 }}
      dpr={[1, 2]}
      frameloop={thirdMode ? "always" : "demand"}
    >
      <Kick />
      <ambientLight intensity={Math.PI / 2} />
      <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} decay={0} intensity={Math.PI} />
      {buildingsData.map((item) => (
        <Building
          key={item.id}
          id={item.id}
          shape={item.shape}
          depth={overrides[String(item.id)] ?? item.baseHeight}
          y={item.baseY}
          isEdited={String(item.id) in overrides}
          tags={item.tags}
          onHeightChange={setHeight}
        />
      ))}

      {terrain && <Terrain center={center} terrain={terrain} />}
      <Roads area={realCenter} terrain={terrain} />
      <pointLight position={[-10, -10, -10]} decay={0} intensity={Math.PI} />
      <Car groundAt={groundAt} />
      <Export />
      <Sky distance={450000} sunPosition={[0, 1, 0]} inclination={0} azimuth={0.25} />
      <Environment preset="city" />
    </Canvas>
    </>
  );
}
