#!/bin/bash
# Tạo project iOS (Capacitor) + cấu hình Info.plist + icon. Chạy ở thư mục gốc dự án sau khi `npm run build`.
set -e
npx cap add ios
PLIST=ios/App/App/Info.plist
# setkey <key> <type> <value>: thêm, nếu đã có thì ghi đè
setkey() {
  /usr/libexec/PlistBuddy -c "Add :$1 $2 $3" "$PLIST" 2>/dev/null \
    || /usr/libexec/PlistBuddy -c "Set :$1 $3" "$PLIST"
}
setkey CFBundleDisplayName string "Map3D"
setkey UIFileSharingEnabled bool true
setkey LSSupportsOpeningDocumentsInPlace bool true
setkey NSLocationWhenInUseUsageDescription string "Map3D dùng vị trí của bạn để căn bản đồ tới nơi bạn đang đứng."
cp resources/icon.png ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png
# Màn hình khởi động: thay mọi ảnh trong Splash.imageset
for f in ios/App/App/Assets.xcassets/Splash.imageset/*.png; do
  [ -f "$f" ] && cp resources/splash.png "$f"
done
npx cap sync ios
