<p align='center'>
<h1 align='center'>🗺️ map3d</h1>
<p align='center'>Generate a real world 3D map</p>
</p>

<p align='center'>
<a href="https://map.fleet.im/">Visit Website</a> · <a href="https://github.com/cartesiancs/map3d/issues">Report Bugs</a>
</p>

![img](./.github/screenshot.png)

## About The Project

This is a 3D building mapping service implemented with [React-Three-Fiber](https://github.com/pmndrs/react-three-fiber). It allows exporting as a GLB file, and all features are free to use. Based on this project, various functionalities such as **digital twin**, **drone surveying**, and **GPS markers** can be implemented.

The map files are based on OpenStreetMap data.

> [!IMPORTANT]
> 📢 <strong>This project cannot guarantee the accuracy of the data.</strong> Since it uses OpenStreetMap data, some height values may be missing or incorrectly recorded. To address this issue, an option will be added in the future to allow users to manually correct the data.

## Roadmap

- [x] Create 3D Buildings
- [x] Create Roads
- [x] Export GLB
- [ ] Building Texture
- [ ] Height Customization
- [ ] Material
- [ ] Heightmap

## Demo

https://github.com/user-attachments/assets/1b61c2f8-dcf9-40bb-9804-59f6a74594dc

## Contributors

Hyeong Jun Huh [(GitHub)](https://github.com/DipokalLab)

## License

MIT License

## Ứng dụng iOS (Capacitor + GitHub Actions)

1. Tạo repo GitHub, đẩy toàn bộ thư mục này lên nhánh `main`.
2. Vào tab **Actions → Build iOS** (tự chạy khi push, hoặc bấm *Run workflow*).
3. Khi xong, tải artifact **Map3D-ipa** → giải nén được `Map3D.ipa`.
4. File `.ipa` là bản **chưa ký**: cài lên iPhone bằng Sideloadly / AltStore (Apple ID miễn phí, hạn 7 ngày) hoặc ký bằng chứng chỉ Developer của bạn.

Chạy máy local (cần macOS + Xcode): `npm install && npm run build && npx cap add ios && npx cap sync ios && npx cap open ios`.
