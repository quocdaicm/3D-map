<p align='center'>
<h1 align='center'>🗺️ map3d</h1>
<p align='center'>Generate a real world 3D map</p>
</p>

<p align='center'>
<a href="https://map.fleet.im/">Visit Website</a> · <a href="https://github.com/cartesiancs/map3d/issues">Report Bugs</a>
</p>

![img](./.github/screenshot.png)

## About The Project

This is a 3D building mapping service implemented with [React-Three-Fiber](https://github.com/pmndrs/react-three-fiber). It allows exporting as a GLB file, and all features are free to use. Based on this project, various functionalities such as **digital twin**, **drone surveying**, and **GPS markers** can be implemented.

The map files are based on OpenStreetMap data.

> [!IMPORTANT]
> 📢 <strong>This project cannot guarantee the accuracy of the data.</strong> Since it uses OpenStreetMap data, some height values may be missing or incorrectly recorded. To address this issue, an option will be added in the future to allow users to manually correct the data.

## Roadmap

- [x] Create 3D Buildings
- [x] Create Roads
- [x] Export GLB
- [ ] Building Texture
- [ ] Height Customization
- [ ] Material
- [ ] Heightmap

## Demo

https://github.com/user-attachments/assets/1b61c2f8-dcf9-40bb-9804-59f6a74594dc

## Contributors

Hyeong Jun Huh [(GitHub)](https://github.com/DipokalLab)

## License

MIT License

## Ứng dụng iOS (Capacitor + GitHub Actions)

1. Tạo repo GitHub, đẩy toàn bộ thư mục này lên nhánh `main`.
2. Vào tab **Actions → Build iOS** (tự chạy khi push, hoặc bấm *Run workflow*).
3. Khi xong, tải artifact **Map3D-ipa** → giải nén được `Map3D.ipa`.
4. File `.ipa` là bản **chưa ký**: cài lên iPhone bằng Sideloadly / AltStore (Apple ID miễn phí, hạn 7 ngày) hoặc ký bằng chứng chỉ Developer của bạn.

Chạy máy local (cần macOS + Xcode): `npm install && npm run build && npx cap add ios && npx cap sync ios && npx cap open ios`.

## Google Maps & địa hình 3D

- **Bản đồ nền + tìm tọa độ**: đặt biến `VITE_GOOGLE_MAPS_API_KEY` (xem `.env.example`; trên GitHub Actions: Settings → Secrets → `GOOGLE_MAPS_API_KEY`). Trong Google Cloud bật **Maps JavaScript API** và **Geocoding API**, bật billing. Không có key (hoặc key bị Google từ chối) thì app tự dùng OpenStreetMap như trước.
- **Khuyến nghị cho key**: giới hạn theo API (chỉ 2 API trên) và đặt hạn mức/ngân sách trong Google Cloud, vì key nằm trong bản build của app.
- **Địa hình 3D**: độ cao lấy từ tile Terrarium (AWS Open Data, miễn phí, không cần key), dựng thành mặt đất; tòa nhà, đường và xe được nâng theo độ cao. Mặt đất cũng nằm trong file xuất (GLB/OBJ/STL/USDZ). Nếu không tải được tile, cảnh hiển thị mặt phẳng như cũ.
- **Không cần key/thẻ**: bản đồ OpenStreetMap có nút đổi lớp *Đường phố / Vệ tinh (Esri) / Địa hình (OpenTopoMap)* ở góc dưới phải; tìm địa điểm dùng Photon, dự phòng Nominatim.
- **Xuất file**: đường được dựng thành mặt đường (mesh) có màu theo loại, tòa nhà tô màu theo loại/công trình, mặt đất dùng ảnh màu theo độ cao nên mở được trong Blender/Unity/Godot. Tòa nhà dạng multipolygon của OSM cũng được lấy.
- **Ảnh vệ tinh làm nền mặt đất** (bước xem 3D, góc trên trái): *Vệ tinh Esri* (nét, chỉ nên dùng cá nhân theo điều khoản Esri), *Sentinel-2* (~10 m, CC BY-NC, phải ghi nguồn) hoặc *Độ cao*. Ảnh được đưa vào file GLB xuất ra. Nếu không tải được thì tự dùng màu theo độ cao.

## Công cụ phát triển (lấy API / giao diện / lỗi)

Bấm **Tùy chọn** (góc trên phải) — mô phỏng mục "Nâng cao & công cụ phát triển" của DESM Mobile:

- **Gói chẩn đoán**: 1 file gộp thiết bị, lỗi, trạng thái app, tóm tắt API, cấu trúc giao diện, CSS. Gặp lỗi thì lưu file này gửi lại.
- **Nhật ký lỗi**: luôn ghi (JS error, promise bị từ chối, console.error/warn, ảnh/script không tải được), giữ cả khi app tải lại.
- **Nhật ký API**: bật công tắc rồi thao tác; lưu JSON đầy đủ / tóm tắt endpoint / văn bản. Khóa/token trong URL được che.
- **Giao diện**: cấu trúc DOM, toàn bộ CSS (gồm CSS emotion), HTML trang.
- **Tải địa chỉ**: GET một URL rồi lưu file (khác domain có thể bị CORS chặn).

Mã: `src/utils/devLog.ts` (bộ ghi + xuất), `src/components/dev/DevToolsPanel.tsx` (giao diện), `src/utils/saveFile.ts` (`saveText`).
