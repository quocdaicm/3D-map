import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.map3d.app",
  appName: "Map3D",
  webDir: "dist",
  ios: {
    contentInset: "never",
    backgroundColor: "#eef3f6",
  },
};

export default config;
